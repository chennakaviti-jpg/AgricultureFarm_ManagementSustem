package com.example.farmmanagement.Controller;

	import java.util.List;

	import org.springframework.http.HttpStatus;
	import org.springframework.http.ResponseEntity;
	import org.springframework.web.bind.annotation.DeleteMapping;
	import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.PathVariable;
	import org.springframework.web.bind.annotation.PostMapping;
	import org.springframework.web.bind.annotation.PutMapping;
	import org.springframework.web.bind.annotation.RequestBody;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.bind.annotation.RestController;

	import com.example.farmmanagement.DTO.request.FarmerRequestDTO;
	import com.example.farmmanagement.DTO.request.FarmerUpdateRequestDTO;
	import com.example.farmmanagement.DTO.response.FarmerResponseDTO;
	import com.example.farmmanagement.service.FarmerService;

	import jakarta.validation.Valid;

	@RestController
	@RequestMapping("/api/farmers")
	public class FarmerController {

	    private final FarmerService farmerService;

	    public FarmerController(FarmerService farmerService) {
	        this.farmerService = farmerService;
	    }

	    @PostMapping
	    public ResponseEntity<FarmerResponseDTO> createFarmer(
	            @Valid @RequestBody FarmerRequestDTO requestDTO) {

	        FarmerResponseDTO response =
	                farmerService.createFarmer(requestDTO);

	        return ResponseEntity.status(HttpStatus.CREATED).body(response);
	    }

	    @GetMapping("/{farmerId}")
	    public ResponseEntity<FarmerResponseDTO> getFarmerById(
	            @PathVariable Long farmerId) {

	        FarmerResponseDTO response =
	                farmerService.getFarmerById(farmerId);

	        return ResponseEntity.ok(response);
	    }

	    @GetMapping
	    public ResponseEntity<List<FarmerResponseDTO>> getAllFarmers() {

	        List<FarmerResponseDTO> response =
	                farmerService.getAllFarmers();

	        return ResponseEntity.ok(response);
	    }

	    @PutMapping("/{farmerId}")
	    public ResponseEntity<FarmerResponseDTO> updateFarmer(
	            @PathVariable Long farmerId,
	            @Valid @RequestBody FarmerUpdateRequestDTO requestDTO) {

	        FarmerResponseDTO response =
	                farmerService.updateFarmer(farmerId, requestDTO);

	        return ResponseEntity.ok(response);
	    }

	    @DeleteMapping("/{farmerId}")
	    public ResponseEntity<Void> deleteFarmer(
	            @PathVariable Long farmerId) {

	        farmerService.deleteFarmer(farmerId);

	        return ResponseEntity.noContent().build();
	    }
	}
package com.example.farmmanagement.enums;

public enum UserRole {
    
	ADMIN,
	FARM_MANAGER,
	FARM_WORKER
}

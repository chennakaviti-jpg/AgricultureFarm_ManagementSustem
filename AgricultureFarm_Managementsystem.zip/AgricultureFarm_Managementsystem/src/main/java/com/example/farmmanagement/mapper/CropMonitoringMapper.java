package com.example.farmmanagement.mapper;

	import org.mapstruct.Mapper;
	import org.mapstruct.Mapping;
	import org.mapstruct.MappingConstants;

	import com.example.farmmanagement.DTO.request.CropMonitoringRequestDTO;
	import com.example.farmmanagement.DTO.response.CropMonitoringResponseDTO;
	import com.example.farmmanagement.entity.CropMonitoring;

	@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
	public interface CropMonitoringMapper {

	    @Mapping(target = "monitoringId", ignore = true)
	    @Mapping(target = "cropPlan.cropPlanId", source = "cropPlanId")
	    CropMonitoring toEntity(CropMonitoringRequestDTO dto);

	    @Mapping(target = "cropPlanId", source = "cropPlan.cropPlanId")
	    CropMonitoringResponseDTO toResponseDTO(CropMonitoring monitoring);
	}
package com.example.farmmanagement.entity;

	import jakarta.persistence.*;
	import jakarta.validation.constraints.NotBlank;
	import jakarta.validation.constraints.Positive;

	import java.util.ArrayList;
	import java.util.List;

	@Entity
	@Table(
	    name = "fields",
	    uniqueConstraints = {
	        @UniqueConstraint(
	            name = "uk_field_name_farm",
	            columnNames = {"farm_id", "field_name"}
	        )
	    }
	)
	public class Field {

	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long fieldId;

	    @NotBlank(message = "Field name is required")
	    @Column(name = "field_name", nullable = false, length = 100)
	    private String fieldName;

	    @Positive(message = "Field area must be greater than zero")
	    @Column(nullable = false)
	    private Double area;

	    @NotBlank(message = "Soil type is required")
	    @Column(name = "soil_type", nullable = false, length = 100)
	    private String soilType;

	    @Column(length = 500)
	    private String description;

	    // Many Fields belong to One Farm
	    @ManyToOne(fetch = FetchType.LAZY, optional = false)
	    @JoinColumn(
	        name = "farm_id",
	        nullable = false,
	        foreignKey = @ForeignKey(name = "fk_field_farm")
	    )
	    private Farm farm;

	    // One Field can have Many Crop Plans
	    @OneToMany(mappedBy = "field", fetch = FetchType.LAZY)
	    private List<CropPlan> cropPlans = new ArrayList<>();

	    public Field() {
	    }

	    public Long getFieldId() {
	        return fieldId;
	    }

	    public void setFieldId(Long fieldId) {
	        this.fieldId = fieldId;
	    }

	    public String getFieldName() {
	        return fieldName;
	    }

	    public void setFieldName(String fieldName) {
	        this.fieldName = fieldName;
	    }

	    public Double getArea() {
	        return area;
	    }

	    public void setArea(Double area) {
	        this.area = area;
	    }

	    public String getSoilType() {
	        return soilType;
	    }

	    public void setSoilType(String soilType) {
	        this.soilType = soilType;
	    }

	    public String getDescription() {
	        return description;
	    }

	    public void setDescription(String description) {
	        this.description = description;
	    }

	    public Farm getFarm() {
	        return farm;
	    }

	    public void setFarm(Farm farm) {
	        this.farm = farm;
	    }

	    public List<CropPlan> getCropPlans() {
	        return cropPlans;
	    }

	    public void setCropPlans(List<CropPlan> cropPlans) {
	        this.cropPlans = cropPlans;
	    }
	}
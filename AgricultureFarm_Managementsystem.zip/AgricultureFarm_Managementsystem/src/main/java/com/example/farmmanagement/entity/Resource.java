package com.example.farmmanagement.entity;

	import com.example.farmmanagement.enums.MeasurementUnit;
	import com.example.farmmanagement.enums.ResourceType;
	import jakarta.persistence.*;
	import jakarta.validation.constraints.NotBlank;
	import jakarta.validation.constraints.NotNull;
	import jakarta.validation.constraints.PositiveOrZero;

	import java.util.ArrayList;
	import java.util.List;

	@Entity
	@Table(
	    name = "resources",
	    uniqueConstraints = {
	        @UniqueConstraint(
	            name = "uk_resource_name_type",
	            columnNames = {"resource_name", "resource_type"}
	        )
	    }
	)
	public class Resource {

	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long resourceId;

	    @NotBlank(message = "Resource name is required")
	    @Column(name = "resource_name", nullable = false, length = 150)
	    private String resourceName;

	    @NotNull(message = "Resource type is required")
	    @Enumerated(EnumType.STRING)
	    @Column(name = "resource_type", nullable = false, length = 50)
	    private ResourceType resourceType;

	    @NotNull(message = "Available quantity is required")
	    @PositiveOrZero(message = "Available quantity cannot be negative")
	    @Column(name = "available_quantity", nullable = false)
	    private Double availableQuantity = 0.0;

	    @NotNull(message = "Unit is required")
	    @Enumerated(EnumType.STRING)
	    @Column(nullable = false, length = 30)
	    private MeasurementUnit unit;

	    @PositiveOrZero(message = "Minimum stock level cannot be negative")
	    @Column(name = "minimum_stock_level", nullable = false)
	    private Double minimumStockLevel = 0.0;

	    @Column(length = 500)
	    private String description;

	    // One Resource can have Many ResourceUsage records
	    @OneToMany(mappedBy = "resource", fetch = FetchType.LAZY)
	    private List<ResourceUsage> resourceUsages = new ArrayList<>();

	    public Resource() {
	    }

	    public Long getResourceId() {
	        return resourceId;
	    }

	    public void setResourceId(Long resourceId) {
	        this.resourceId = resourceId;
	    }

	    public String getResourceName() {
	        return resourceName;
	    }

	    public void setResourceName(String resourceName) {
	        this.resourceName = resourceName;
	    }

	    public ResourceType getResourceType() {
	        return resourceType;
	    }

	    public void setResourceType(ResourceType resourceType) {
	        this.resourceType = resourceType;
	    }

	    public Double getAvailableQuantity() {
	        return availableQuantity;
	    }

	    public void setAvailableQuantity(Double availableQuantity) {
	        this.availableQuantity = availableQuantity;
	    }

	    public MeasurementUnit getUnit() {
	        return unit;
	    }

	    public void setUnit(MeasurementUnit unit) {
	        this.unit = unit;
	    }

	    public Double getMinimumStockLevel() {
	        return minimumStockLevel;
	    }

	    public void setMinimumStockLevel(Double minimumStockLevel) {
	        this.minimumStockLevel = minimumStockLevel;
	    }

	    public String getDescription() {
	        return description;
	    }

	    public void setDescription(String description) {
	        this.description = description;
	    }

	    public List<ResourceUsage> getResourceUsages() {
	        return resourceUsages;
	    }

	    public void setResourceUsages(List<ResourceUsage> resourceUsages) {
	        this.resourceUsages = resourceUsages;
	    }
	}
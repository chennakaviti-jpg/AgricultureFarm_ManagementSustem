package com.example.farmmanagement.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.example.farmmanagement.DTO.request.FarmDocumentRequestDTO;
import com.example.farmmanagement.DTO.request.FarmDocumentUpdateRequestDTO;
import com.example.farmmanagement.DTO.response.FarmDocumentResponseDTO;
import com.example.farmmanagement.entity.Farm;
import com.example.farmmanagement.entity.FarmDocument;
import com.example.farmmanagement.enums.DocumentType;
import com.example.farmmanagement.exception.ResourceNotFoundException;
import com.example.farmmanagement.mapper.FarmDocumentMapper;
import com.example.farmmanagement.repository.FarmDocumentRepository;
import com.example.farmmanagement.repository.FarmRepository;
import com.example.farmmanagement.service.storage.FileStorageService;

@Service
@Transactional
public class FarmDocumentServiceImpl implements FarmDocumentService {

    private final FarmDocumentRepository farmDocumentRepository;
    private final FarmDocumentMapper farmDocumentMapper;
    private final FarmRepository farmRepository;
    private final FileStorageService fileStorageService;

    public FarmDocumentServiceImpl(
            FarmDocumentRepository farmDocumentRepository,
            FarmDocumentMapper farmDocumentMapper,
            FarmRepository farmRepository,
            FileStorageService fileStorageService) {

        this.farmDocumentRepository = farmDocumentRepository;
        this.farmDocumentMapper = farmDocumentMapper;
        this.farmRepository = farmRepository;
        this.fileStorageService = fileStorageService;
    }

    @Override
    public FarmDocumentResponseDTO createDocument(
            FarmDocumentRequestDTO requestDTO) {

        FarmDocument document = farmDocumentMapper.toEntity(requestDTO);

        Farm farm = farmRepository.findById(requestDTO.getFarmId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Farm not found with ID: " + requestDTO.getFarmId()));

        document.setFarm(farm);

        throw new IllegalArgumentException(
                "Use the file upload endpoint to create a farm document.");
    }

    @Override
    @Transactional(readOnly = true)
    public FarmDocumentResponseDTO getDocumentById(Long documentId) {

        FarmDocument document = farmDocumentRepository.findById(documentId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Farm document not found with ID: " + documentId));

        return farmDocumentMapper.toResponseDTO(document);
    }

    @Override
    @Transactional(readOnly = true)
    public List<FarmDocumentResponseDTO> getAllDocuments() {

        return farmDocumentRepository.findAll()
                .stream()
                .map(farmDocumentMapper::toResponseDTO)
                .toList();
    }

    @Override
    public FarmDocumentResponseDTO updateDocument(
            Long documentId,
            FarmDocumentUpdateRequestDTO requestDTO) {

        FarmDocument document = farmDocumentRepository.findById(documentId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Farm document not found with ID: " + documentId));

        document.setDocumentType(requestDTO.getDocumentType());
        document.setDescription(requestDTO.getDescription());

        return farmDocumentMapper.toResponseDTO(
                farmDocumentRepository.save(document));
    }

    @Override
    public void deleteDocument(Long documentId) {

        FarmDocument document = farmDocumentRepository.findById(documentId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Farm document not found with ID: " + documentId));

        farmDocumentRepository.delete(document);

        try {
            fileStorageService.deleteFile(document.getStoredFileName());
        } catch (IllegalStateException exception) {
            // Database deletion has already been requested.
            // File cleanup can be retried separately if needed.
        }
    }

    @Override
    public FarmDocumentResponseDTO uploadDocument(
            Long farmId,
            DocumentType documentType,
            String description,
            MultipartFile file) {

        Farm farm = farmRepository.findById(farmId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Farm not found with ID: " + farmId));

        if (documentType == null) {
            throw new IllegalArgumentException(
                    "Document type is required.");
        }

        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException(
                    "Please select a file to upload.");
        }

        String contentType = file.getContentType();

        if (contentType == null || contentType.isBlank()) {
            contentType = "application/octet-stream";
        }

        String originalFileName = file.getOriginalFilename();

        if (originalFileName == null || originalFileName.isBlank()) {
            throw new IllegalArgumentException(
                    "Original file name is required.");
        }

        String storedFileName = fileStorageService.storeFile(file);

        try {
            FarmDocument document = new FarmDocument();

            document.setFarm(farm);
            document.setOriginalFileName(
                    Path.of(originalFileName).getFileName().toString());
            document.setStoredFileName(storedFileName);
            document.setFileType(contentType);
            document.setDocumentType(documentType);
            document.setFileSize(file.getSize());
            document.setUploadedAt(LocalDateTime.now());
            document.setDescription(description);

            return farmDocumentMapper.toResponseDTO(
                    farmDocumentRepository.save(document));

        } catch (RuntimeException exception) {
            fileStorageService.deleteFile(storedFileName);
            throw exception;
        }
    }

    @Override
    @Transactional(readOnly = true)
    public Resource downloadDocument(Long documentId) {

        FarmDocument document = farmDocumentRepository.findById(documentId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Farm document not found with ID: " + documentId));

        Path filePath = fileStorageService.loadFile(
                document.getStoredFileName());

        try {
            Resource resource = new UrlResource(filePath.toUri());

            if (!resource.exists() || !resource.isReadable()) {
                throw new ResourceNotFoundException(
                        "Stored file not found for document ID: " + documentId);
            }

            return resource;

        } catch (IOException exception) {
            throw new IllegalStateException(
                    "Could not read the stored file.", exception);
        }
    }
}
package com.example.farmmanagement.entity;

	import jakarta.persistence.*;
	import jakarta.validation.constraints.NotBlank;
	import jakarta.validation.constraints.NotNull;

	import java.time.LocalDate;

	@Entity
	@Table(name = "crop_monitoring")
	public class CropMonitoring {

	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long monitoringId;

	    @ManyToOne(fetch = FetchType.LAZY, optional = false)
	    @JoinColumn(
	        name = "crop_plan_id",
	        nullable = false,
	        foreignKey = @ForeignKey(name = "fk_monitoring_crop_plan")
	    )
	    private CropPlan cropPlan;

	    @NotNull(message = "Monitoring date is required")
	    @Column(name = "monitoring_date", nullable = false)
	    private LocalDate monitoringDate;

	    @NotBlank(message = "Crop growth stage is required")
	    @Column(name = "growth_stage", nullable = false, length = 100)
	    private String growthStage;

	    @NotBlank(message = "Crop health status is required")
	    @Column(name = "health_status", nullable = false, length = 100)
	    private String healthStatus;

	    @Column(name = "pest_detected", nullable = false)
	    private Boolean pestDetected = false;

	    @Column(name = "disease_detected", nullable = false)
	    private Boolean diseaseDetected = false;

	    @Column(length = 1000)
	    private String observations;

	    public CropMonitoring() {
	    }

	    public Long getMonitoringId() {
	        return monitoringId;
	    }

	    public void setMonitoringId(Long monitoringId) {
	        this.monitoringId = monitoringId;
	    }

	    public CropPlan getCropPlan() {
	        return cropPlan;
	    }

	    public void setCropPlan(CropPlan cropPlan) {
	        this.cropPlan = cropPlan;
	    }

	    public LocalDate getMonitoringDate() {
	        return monitoringDate;
	    }

	    public void setMonitoringDate(LocalDate monitoringDate) {
	        this.monitoringDate = monitoringDate;
	    }

	    public String getGrowthStage() {
	        return growthStage;
	    }

	    public void setGrowthStage(String growthStage) {
	        this.growthStage = growthStage;
	    }

	    public String getHealthStatus() {
	        return healthStatus;
	    }

	    public void setHealthStatus(String healthStatus) {
	        this.healthStatus = healthStatus;
	    }

	    public Boolean getPestDetected() {
	        return pestDetected;
	    }

	    public void setPestDetected(Boolean pestDetected) {
	        this.pestDetected = pestDetected;
	    }

	    public Boolean getDiseaseDetected() {
	        return diseaseDetected;
	    }

	    public void setDiseaseDetected(Boolean diseaseDetected) {
	        this.diseaseDetected = diseaseDetected;
	    }

	    public String getObservations() {
	        return observations;
	    }

	    public void setObservations(String observations) {
	        this.observations = observations;
	    }
	}
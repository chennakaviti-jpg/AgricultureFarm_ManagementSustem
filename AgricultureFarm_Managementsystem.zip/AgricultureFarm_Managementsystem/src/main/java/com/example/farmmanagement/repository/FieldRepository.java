package com.example.farmmanagement.repository;

	import org.springframework.data.jpa.repository.JpaRepository;
	import org.springframework.stereotype.Repository;

	import com.example.farmmanagement.entity.Field;

	@Repository
	public interface FieldRepository extends JpaRepository<Field, Long> {

	}
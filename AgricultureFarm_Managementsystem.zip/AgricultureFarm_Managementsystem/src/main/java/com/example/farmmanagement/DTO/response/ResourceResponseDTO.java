package com.example.farmmanagement.DTO.response;

	import com.example.farmmanagement.enums.MeasurementUnit;
	import com.example.farmmanagement.enums.ResourceType;

	public class ResourceResponseDTO {

	    private Long resourceId;
	    private String resourceName;
	    private ResourceType resourceType;
	    private Double availableQuantity;
	    private MeasurementUnit unit;
	    private Double minimumStockLevel;
	    private String description;

	    public ResourceResponseDTO() {
	    }

	    public Long getResourceId() {
	        return resourceId;
	    }

	    public void setResourceId(Long resourceId) {
	        this.resourceId = resourceId;
	    }

	    public String getResourceName() {
	        return resourceName;
	    }

	    public void setResourceName(String resourceName) {
	        this.resourceName = resourceName;
	    }

	    public ResourceType getResourceType() {
	        return resourceType;
	    }

	    public void setResourceType(ResourceType resourceType) {
	        this.resourceType = resourceType;
	    }

	    public Double getAvailableQuantity() {
	        return availableQuantity;
	    }

	    public void setAvailableQuantity(Double availableQuantity) {
	        this.availableQuantity = availableQuantity;
	    }

	    public MeasurementUnit getUnit() {
	        return unit;
	    }

	    public void setUnit(MeasurementUnit unit) {
	        this.unit = unit;
	    }

	    public Double getMinimumStockLevel() {
	        return minimumStockLevel;
	    }

	    public void setMinimumStockLevel(Double minimumStockLevel) {
	        this.minimumStockLevel = minimumStockLevel;
	    }

	    public String getDescription() {
	        return description;
	    }

	    public void setDescription(String description) {
	        this.description = description;
	    }
	}
package com.example.farmmanagement.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.farmmanagement.DTO.request.CropMonitoringRequestDTO;
import com.example.farmmanagement.DTO.request.CropMonitoringUpdateRequestDTO;
import com.example.farmmanagement.DTO.response.CropMonitoringResponseDTO;
import com.example.farmmanagement.entity.CropMonitoring;
import com.example.farmmanagement.exception.ResourceNotFoundException;
import com.example.farmmanagement.mapper.CropMonitoringMapper;
import com.example.farmmanagement.repository.CropMonitoringRepository;

@Service
@Transactional
public class CropMonitoringServiceImpl implements CropMonitoringService {

    private final CropMonitoringRepository cropMonitoringRepository;
    private final CropMonitoringMapper cropMonitoringMapper;

    public CropMonitoringServiceImpl(
            CropMonitoringRepository cropMonitoringRepository,
            CropMonitoringMapper cropMonitoringMapper) {
        this.cropMonitoringRepository = cropMonitoringRepository;
        this.cropMonitoringMapper = cropMonitoringMapper;
    }

    // Record Crop Monitoring
    @Override
    public CropMonitoringResponseDTO recordMonitoring(
            CropMonitoringRequestDTO requestDTO) {

        CropMonitoring monitoring =
                cropMonitoringMapper.toEntity(requestDTO);

        CropMonitoring savedMonitoring =
                cropMonitoringRepository.save(monitoring);

        return cropMonitoringMapper.toResponseDTO(savedMonitoring);
    }

    // Get Monitoring Record By ID
    @Override
    @Transactional(readOnly = true)
    public CropMonitoringResponseDTO getMonitoringById(
            Long monitoringId) {

        CropMonitoring monitoring =
                cropMonitoringRepository.findById(monitoringId)
                        .orElseThrow(() -> new ResourceNotFoundException(
                                "Crop monitoring record not found with ID: "
                                        + monitoringId));

        return cropMonitoringMapper.toResponseDTO(monitoring);
    }

    // Get All Monitoring Records
    @Override
    @Transactional(readOnly = true)
    public List<CropMonitoringResponseDTO> getAllMonitoringRecords() {

        return cropMonitoringRepository.findAll()
                .stream()
                .map(cropMonitoringMapper::toResponseDTO)
                .toList();
    }

    // Update Monitoring Record
    @Override
    public CropMonitoringResponseDTO updateMonitoring(
            Long monitoringId,
            CropMonitoringUpdateRequestDTO requestDTO) {

        CropMonitoring monitoring =
                cropMonitoringRepository.findById(monitoringId)
                        .orElseThrow(() -> new ResourceNotFoundException(
                                "Crop monitoring record not found with ID: "
                                        + monitoringId));

        monitoring.setMonitoringDate(requestDTO.getMonitoringDate());
        monitoring.setGrowthStage(requestDTO.getGrowthStage());
        monitoring.setHealthStatus(requestDTO.getHealthStatus());
        monitoring.setPestDetected(requestDTO.getPestDetected());
        monitoring.setDiseaseDetected(requestDTO.getDiseaseDetected());
        monitoring.setObservations(requestDTO.getObservations());

        CropMonitoring updatedMonitoring =
                cropMonitoringRepository.save(monitoring);

        return cropMonitoringMapper.toResponseDTO(updatedMonitoring);
    }

    // Delete Monitoring Record
    @Override
    public void deleteMonitoring(Long monitoringId) {

        CropMonitoring monitoring =
                cropMonitoringRepository.findById(monitoringId)
                        .orElseThrow(() -> new ResourceNotFoundException(
                                "Crop monitoring record not found with ID: "
                                        + monitoringId));

        cropMonitoringRepository.delete(monitoring);
    }
}
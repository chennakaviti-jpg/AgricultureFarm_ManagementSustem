package com.example.farmmanagement.DTO.request;

	import java.time.LocalDate;

	import com.example.farmmanagement.enums.MeasurementUnit;

	import jakarta.validation.constraints.DecimalMin;
	import jakarta.validation.constraints.NotNull;
	import jakarta.validation.constraints.Positive;
	import jakarta.validation.constraints.Size;

	public class HarvestRequestDTO {

	    @NotNull(message = "Crop plan ID is required")
	    @Positive(message = "Crop plan ID must be positive")
	    private Long cropPlanId;

	    @NotNull(message = "Harvest date is required")
	    private LocalDate harvestDate;

	    @NotNull(message = "Harvest quantity is required")
	    @DecimalMin(value = "0.0", inclusive = false,
	            message = "Harvest quantity must be greater than zero")
	    private Double quantity;

	    @NotNull(message = "Measurement unit is required")
	    private MeasurementUnit unit;

	    @NotNull(message = "Expected price is required")
	    @DecimalMin(value = "0.0",
	            message = "Expected price cannot be negative")
	    private Double expectedPrice;

	    private Double actualRevenue;

	    @Size(max = 500, message = "Remarks cannot exceed 500 characters")
	    private String remarks;

	    public HarvestRequestDTO() {
	    }

	    public Long getCropPlanId() {
	        return cropPlanId;
	    }

	    public void setCropPlanId(Long cropPlanId) {
	        this.cropPlanId = cropPlanId;
	    }

	    public LocalDate getHarvestDate() {
	        return harvestDate;
	    }

	    public void setHarvestDate(LocalDate harvestDate) {
	        this.harvestDate = harvestDate;
	    }

	    public Double getQuantity() {
	        return quantity;
	    }

	    public void setQuantity(Double quantity) {
	        this.quantity = quantity;
	    }

	    public MeasurementUnit getUnit() {
	        return unit;
	    }

	    public void setUnit(MeasurementUnit unit) {
	        this.unit = unit;
	    }

	    public Double getExpectedPrice() {
	        return expectedPrice;
	    }

	    public void setExpectedPrice(Double expectedPrice) {
	        this.expectedPrice = expectedPrice;
	    }

	    public Double getActualRevenue() {
	        return actualRevenue;
	    }

	    public void setActualRevenue(Double actualRevenue) {
	        this.actualRevenue = actualRevenue;
	    }

	    public String getRemarks() {
	        return remarks;
	    }

	    public void setRemarks(String remarks) {
	        this.remarks = remarks;
	    }
	}
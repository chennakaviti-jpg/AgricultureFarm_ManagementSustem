package com.example.farmmanagement.mapper;

	import org.mapstruct.Mapper;
	import org.mapstruct.Mapping;
	import org.mapstruct.MappingConstants;

	import com.example.farmmanagement.DTO.request.FieldRequestDTO;
	import com.example.farmmanagement.DTO.response.FieldResponseDTO;
	import com.example.farmmanagement.entity.Field;

	@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
	public interface FieldMapper {

	    @Mapping(target = "fieldId", ignore = true)
	    @Mapping(target = "farm.farmId", source = "farmId")
	    Field toEntity(FieldRequestDTO dto);

	    @Mapping(target = "farmId", source = "farm.farmId")
	    FieldResponseDTO toResponseDTO(Field field);
	}
package com.example.farmmanagement.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.farmmanagement.DTO.request.FieldRequestDTO;
import com.example.farmmanagement.DTO.request.FieldUpdateRequestDTO;
import com.example.farmmanagement.DTO.response.FieldResponseDTO;
import com.example.farmmanagement.entity.Field;
import com.example.farmmanagement.exception.ResourceNotFoundException;
import com.example.farmmanagement.mapper.FieldMapper;
import com.example.farmmanagement.repository.FieldRepository;

@Service
@Transactional
public class FieldServiceImpl implements FieldService {

    private final FieldRepository fieldRepository;
    private final FieldMapper fieldMapper;

    public FieldServiceImpl(
            FieldRepository fieldRepository,
            FieldMapper fieldMapper) {
        this.fieldRepository = fieldRepository;
        this.fieldMapper = fieldMapper;
    }

    // Create Field
    @Override
    public FieldResponseDTO createField(FieldRequestDTO requestDTO) {
        Field field = fieldMapper.toEntity(requestDTO);

        Field savedField = fieldRepository.save(field);

        return fieldMapper.toResponseDTO(savedField);
    }

    // Get Field By ID
    @Override
    @Transactional(readOnly = true)
    public FieldResponseDTO getFieldById(Long fieldId) {
        Field field = fieldRepository.findById(fieldId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Field not found with ID: " + fieldId));

        return fieldMapper.toResponseDTO(field);
    }

    // Get All Fields
    @Override
    @Transactional(readOnly = true)
    public List<FieldResponseDTO> getAllFields() {
        return fieldRepository.findAll()
                .stream()
                .map(fieldMapper::toResponseDTO)
                .toList();
    }

    // Update Field
    @Override
    public FieldResponseDTO updateField(
            Long fieldId,
            FieldUpdateRequestDTO requestDTO) {

        Field field = fieldRepository.findById(fieldId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Field not found with ID: " + fieldId));

        field.setFieldName(requestDTO.getFieldName());
        field.setArea(requestDTO.getArea());
        field.setSoilType(requestDTO.getSoilType());
        field.setDescription(requestDTO.getDescription());

        Field updatedField = fieldRepository.save(field);

        return fieldMapper.toResponseDTO(updatedField);
    }

    // Delete Field
    @Override
    public void deleteField(Long fieldId) {
        Field field = fieldRepository.findById(fieldId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Field not found with ID: " + fieldId));

        fieldRepository.delete(field);
    }
}
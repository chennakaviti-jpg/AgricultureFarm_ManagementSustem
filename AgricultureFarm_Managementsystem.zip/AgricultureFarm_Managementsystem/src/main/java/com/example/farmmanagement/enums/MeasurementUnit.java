package com.example.farmmanagement.enums;

public enum MeasurementUnit {
	
	    KG,
	    GRAM,
	    TON,
	    LITRE,
	    MILLILITRE,
	    PIECE,
	    HOUR,
	    ACRE,
	    HECTARE
	}
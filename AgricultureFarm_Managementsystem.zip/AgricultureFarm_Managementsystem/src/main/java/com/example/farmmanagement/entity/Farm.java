package com.example.farmmanagement.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Positive;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(
    name = "farms",
    uniqueConstraints = {
        @UniqueConstraint(
            name = "uk_farm_name_farmer",
            columnNames = {"farmer_id", "farm_name"}
        )
    }
)
public class Farm extends BaseAuditableEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long farmId;

    // Optimistic locking / Versioning
    @Version
    @Column(nullable = false)
    private Long version;

    @NotBlank(message = "Farm name is required")
    @Column(name = "farm_name", nullable = false, length = 100)
    private String farmName;

    @NotBlank(message = "Location is required")
    @Column(nullable = false, length = 200)
    private String location;

    @Positive(message = "Farm area must be greater than zero")
    @Column(nullable = false)
    private Double totalArea;

    @Column(length = 500)
    private String description;

    // Many Farms belong to One Farmer
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(
        name = "farmer_id",
        nullable = false,
        foreignKey = @ForeignKey(name = "fk_farm_farmer")
    )
    private Farmer farmer;

    // One Farm can contain Many Fields
    @OneToMany(mappedBy = "farm", fetch = FetchType.LAZY)
    private List<Field> fields = new ArrayList<>();

    // One Farm can have Many Documents
    @OneToMany(mappedBy = "farm", fetch = FetchType.LAZY)
    private List<FarmDocument> documents = new ArrayList<>();

    public Farm() {
    }

    public Long getFarmId() {
        return farmId;
    }

    public void setFarmId(Long farmId) {
        this.farmId = farmId;
    }

    public Long getVersion() {
        return version;
    }

    public String getFarmName() {
        return farmName;
    }

    public void setFarmName(String farmName) {
        this.farmName = farmName;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Double getTotalArea() {
        return totalArea;
    }

    public void setTotalArea(Double totalArea) {
        this.totalArea = totalArea;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Farmer getFarmer() {
        return farmer;
    }

    public void setFarmer(Farmer farmer) {
        this.farmer = farmer;
    }

    public List<Field> getFields() {
        return fields;
    }

    public void setFields(List<Field> fields) {
        this.fields = fields;
    }

    public List<FarmDocument> getDocuments() {
        return documents;
    }

    public void setDocuments(List<FarmDocument> documents) {
        this.documents = documents;
    }
}
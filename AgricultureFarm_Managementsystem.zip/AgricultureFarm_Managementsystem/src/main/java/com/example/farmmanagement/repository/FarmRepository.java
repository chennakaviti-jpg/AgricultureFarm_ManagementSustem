package com.example.farmmanagement.repository;

	import org.springframework.data.jpa.repository.JpaRepository;
	import org.springframework.stereotype.Repository;

	import com.example.farmmanagement.entity.Farm;

	@Repository
	public interface FarmRepository extends JpaRepository<Farm, Long> {

	}
package com.example.farmmanagement.security;

	import java.util.Collection;
	import java.util.List;

	import org.springframework.security.core.GrantedAuthority;
	import org.springframework.security.core.authority.SimpleGrantedAuthority;
	import org.springframework.security.core.userdetails.UserDetails;
	import org.springframework.security.core.userdetails.UserDetailsService;
	import org.springframework.security.core.userdetails.UsernameNotFoundException;
	import org.springframework.stereotype.Service;

	import com.example.farmmanagement.entity.AppUser;
	import com.example.farmmanagement.repository.AppUserRepository;

	@Service
	public class CustomUserDetailsService implements UserDetailsService {

	    private final AppUserRepository appUserRepository;

	    public CustomUserDetailsService(
	            AppUserRepository appUserRepository) {
	        this.appUserRepository = appUserRepository;
	    }

	    @Override
	    public UserDetails loadUserByUsername(String username)
	            throws UsernameNotFoundException {

	        AppUser appUser = appUserRepository.findByUsername(username)
	                .orElseThrow(() -> new UsernameNotFoundException(
	                        "User not found: " + username));

	        return new UserDetails() {

	            @Override
	            public Collection<? extends GrantedAuthority> getAuthorities() {
	                return List.of(
	                        new SimpleGrantedAuthority(
	                                "ROLE_" + appUser.getRole().name()));
	            }

	            @Override
	            public String getPassword() {
	                return appUser.getPassword();
	            }

	            @Override
	            public String getUsername() {
	                return appUser.getUsername();
	            }

	            @Override
	            public boolean isAccountNonExpired() {
	                return true;
	            }

	            @Override
	            public boolean isAccountNonLocked() {
	                return true;
	            }

	            @Override
	            public boolean isCredentialsNonExpired() {
	                return true;
	            }

	            @Override
	            public boolean isEnabled() {
	                return appUser.isEnabled();
	            }
	        };
	    }
	}

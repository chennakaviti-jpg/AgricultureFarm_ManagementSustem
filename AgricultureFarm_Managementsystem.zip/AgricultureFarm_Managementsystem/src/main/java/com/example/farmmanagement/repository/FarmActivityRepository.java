package com.example.farmmanagement.repository;

	import org.springframework.data.jpa.repository.JpaRepository;
	import org.springframework.stereotype.Repository;

	import com.example.farmmanagement.entity.FarmActivity;

	@Repository
	public interface FarmActivityRepository extends JpaRepository<FarmActivity, Long> {

	}
package com.example.farmmanagement.service;

	import java.util.List;

	import com.example.farmmanagement.DTO.request.FarmRequestDTO;
	import com.example.farmmanagement.DTO.request.FarmUpdateRequestDTO;
	import com.example.farmmanagement.DTO.response.FarmResponseDTO;

	public interface FarmService {

	    FarmResponseDTO createFarm(FarmRequestDTO requestDTO);

	    FarmResponseDTO getFarmById(Long farmId);

	    List<FarmResponseDTO> getAllFarms();

	    FarmResponseDTO updateFarm(
	            Long farmId,
	            FarmUpdateRequestDTO requestDTO);

	    void deleteFarm(Long farmId);
	}
package com.example.farmmanagement.mapper;

	import org.mapstruct.Mapper;
	import org.mapstruct.Mapping;
	import org.mapstruct.MappingConstants;

	import com.example.farmmanagement.DTO.request.FarmRequestDTO;
	import com.example.farmmanagement.DTO.response.FarmResponseDTO;
	import com.example.farmmanagement.entity.Farm;

	@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
	public interface FarmMapper {

	    @Mapping(target = "farmId", ignore = true)
	    @Mapping(target = "farmer.farmerId", source = "farmerId")
	    Farm toEntity(FarmRequestDTO dto);

	    @Mapping(target = "farmerId", source = "farmer.farmerId")
	    FarmResponseDTO toResponseDTO(Farm farm);
	}
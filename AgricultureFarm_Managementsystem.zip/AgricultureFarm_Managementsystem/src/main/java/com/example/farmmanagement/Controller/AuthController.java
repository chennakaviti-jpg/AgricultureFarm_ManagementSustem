package com.example.farmmanagement.Controller;

	import org.springframework.http.HttpStatus;
	import org.springframework.http.ResponseEntity;
	import org.springframework.web.bind.annotation.PostMapping;
	import org.springframework.web.bind.annotation.RequestBody;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.bind.annotation.RestController;

	import com.example.farmmanagement.DTO.request.RegisterRequestDTO;
	import com.example.farmmanagement.DTO.response.AuthResponseDTO;
	import com.example.farmmanagement.service.AuthService;

	import jakarta.validation.Valid;
import com.example.farmmanagement.DTO.request.LoginRequestDTO;
	@RestController
	@RequestMapping("/api/auth")
	public class AuthController {

	    private final AuthService authService;

	    public AuthController(AuthService authService) {
	        this.authService = authService;
	    }

	    @PostMapping("/register")
	    public ResponseEntity<AuthResponseDTO> register(
	            @Valid @RequestBody RegisterRequestDTO request) {

	        AuthResponseDTO response = authService.register(request);

	        return ResponseEntity
	                .status(HttpStatus.CREATED)
	                .body(response);
	    }
	    @PostMapping("/login")
	    public ResponseEntity<AuthResponseDTO> login(
	            @Valid @RequestBody LoginRequestDTO request) {

	        AuthResponseDTO response = authService.login(request);

	        return ResponseEntity.ok(response);
	    }
	}
package com.example.farmmanagement.mapper;

	import org.mapstruct.Mapper;
	import org.mapstruct.Mapping;
	import org.mapstruct.MappingConstants;

	import com.example.farmmanagement.DTO.request.CropRequestDTO;
	import com.example.farmmanagement.DTO.response.CropResponseDTO;
	import com.example.farmmanagement.entity.Crop;

	@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
	public interface CropMapper {

	    @Mapping(target = "cropId", ignore = true)
	    Crop toEntity(CropRequestDTO dto);

	    CropResponseDTO toResponseDTO(Crop crop);
	}
package com.example.farmmanagement.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.farmmanagement.DTO.request.FarmerRequestDTO;
import com.example.farmmanagement.DTO.request.FarmerUpdateRequestDTO;
import com.example.farmmanagement.DTO.response.FarmerResponseDTO;
import com.example.farmmanagement.entity.Farmer;
import com.example.farmmanagement.exception.ResourceNotFoundException;
import com.example.farmmanagement.mapper.FarmerMapper;
import com.example.farmmanagement.repository.FarmerRepository;

@Service
@Transactional
public class FarmerServiceImpl implements FarmerService {

    private final FarmerRepository farmerRepository;
    private final FarmerMapper farmerMapper;

    public FarmerServiceImpl(
            FarmerRepository farmerRepository,
            FarmerMapper farmerMapper) {
        this.farmerRepository = farmerRepository;
        this.farmerMapper = farmerMapper;
    }

    // Create Farmer
    @Override
    public FarmerResponseDTO createFarmer(FarmerRequestDTO requestDTO) {

        Farmer farmer = farmerMapper.toEntity(requestDTO);

        Farmer savedFarmer = farmerRepository.save(farmer);

        return farmerMapper.toResponseDTO(savedFarmer);
    }

    // Get Farmer By ID
    @Override
    @Transactional(readOnly = true)
    public FarmerResponseDTO getFarmerById(Long farmerId) {

        Farmer farmer = farmerRepository.findById(farmerId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Farmer not found with ID: " + farmerId));

        return farmerMapper.toResponseDTO(farmer);
    }

    // Get All Farmers
    @Override
    @Transactional(readOnly = true)
    public List<FarmerResponseDTO> getAllFarmers() {

        return farmerRepository.findAll()
                .stream()
                .map(farmerMapper::toResponseDTO)
                .toList();
    }

    // Update Farmer
    @Override
    public FarmerResponseDTO updateFarmer(
            Long farmerId,
            FarmerUpdateRequestDTO requestDTO) {

        Farmer farmer = farmerRepository.findById(farmerId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Farmer not found with ID: " + farmerId));

        farmer.setName(requestDTO.getName());
        farmer.setPhone(requestDTO.getPhone());
        farmer.setEmail(requestDTO.getEmail());
        farmer.setAddress(requestDTO.getAddress());

        Farmer updatedFarmer = farmerRepository.save(farmer);

        return farmerMapper.toResponseDTO(updatedFarmer);
    }

    // Delete Farmer
    @Override
    public void deleteFarmer(Long farmerId) {

        Farmer farmer = farmerRepository.findById(farmerId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Farmer not found with ID: " + farmerId));

        farmerRepository.delete(farmer);
    }
}
package com.example.farmmanagement.DTO.request;

	import java.time.LocalDate;

	import jakarta.validation.constraints.NotBlank;
	import jakarta.validation.constraints.NotNull;
	import jakarta.validation.constraints.Size;

	public class CropMonitoringUpdateRequestDTO {

	    @NotNull(message = "Monitoring date is required")
	    private LocalDate monitoringDate;

	    @NotBlank(message = "Growth stage is required")
	    @Size(max = 100, message = "Growth stage cannot exceed 100 characters")
	    private String growthStage;

	    @NotBlank(message = "Health status is required")
	    @Size(max = 100, message = "Health status cannot exceed 100 characters")
	    private String healthStatus;

	    @NotNull(message = "Pest detection status is required")
	    private Boolean pestDetected;

	    @NotNull(message = "Disease detection status is required")
	    private Boolean diseaseDetected;

	    @Size(max = 1000, message = "Observations cannot exceed 1000 characters")
	    private String observations;

	    public CropMonitoringUpdateRequestDTO() {
	    }

	    public LocalDate getMonitoringDate() {
	        return monitoringDate;
	    }

	    public void setMonitoringDate(LocalDate monitoringDate) {
	        this.monitoringDate = monitoringDate;
	    }

	    public String getGrowthStage() {
	        return growthStage;
	    }

	    public void setGrowthStage(String growthStage) {
	        this.growthStage = growthStage;
	    }

	    public String getHealthStatus() {
	        return healthStatus;
	    }

	    public void setHealthStatus(String healthStatus) {
	        this.healthStatus = healthStatus;
	    }

	    public Boolean getPestDetected() {
	        return pestDetected;
	    }

	    public void setPestDetected(Boolean pestDetected) {
	        this.pestDetected = pestDetected;
	    }

	    public Boolean getDiseaseDetected() {
	        return diseaseDetected;
	    }

	    public void setDiseaseDetected(Boolean diseaseDetected) {
	        this.diseaseDetected = diseaseDetected;
	    }

	    public String getObservations() {
	        return observations;
	    }

	    public void setObservations(String observations) {
	        this.observations = observations;
	    }
	}
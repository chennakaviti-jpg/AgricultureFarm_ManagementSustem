package com.example.farmmanagement.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.farmmanagement.DTO.request.FarmActivityRequestDTO;
import com.example.farmmanagement.DTO.request.FarmActivityUpdateRequestDTO;
import com.example.farmmanagement.DTO.response.FarmActivityResponseDTO;
import com.example.farmmanagement.entity.FarmActivity;
import com.example.farmmanagement.exception.ResourceNotFoundException;
import com.example.farmmanagement.mapper.FarmActivityMapper;
import com.example.farmmanagement.repository.FarmActivityRepository;

@Service
@Transactional
public class FarmActivityServiceImpl implements FarmActivityService {

    private final FarmActivityRepository farmActivityRepository;
    private final FarmActivityMapper farmActivityMapper;

    public FarmActivityServiceImpl(
            FarmActivityRepository farmActivityRepository,
            FarmActivityMapper farmActivityMapper) {
        this.farmActivityRepository = farmActivityRepository;
        this.farmActivityMapper = farmActivityMapper;
    }

    // Create Farm Activity
    @Override
    public FarmActivityResponseDTO createActivity(
            FarmActivityRequestDTO requestDTO) {

        FarmActivity activity = farmActivityMapper.toEntity(requestDTO);
        FarmActivity savedActivity = farmActivityRepository.save(activity);

        return farmActivityMapper.toResponseDTO(savedActivity);
    }

    // Get Farm Activity By ID
    @Override
    @Transactional(readOnly = true)
    public FarmActivityResponseDTO getActivityById(Long activityId) {

        FarmActivity activity = farmActivityRepository.findById(activityId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Farm activity not found with ID: " + activityId));

        return farmActivityMapper.toResponseDTO(activity);
    }

    // Get All Farm Activities
    @Override
    @Transactional(readOnly = true)
    public List<FarmActivityResponseDTO> getAllActivities() {

        return farmActivityRepository.findAll()
                .stream()
                .map(farmActivityMapper::toResponseDTO)
                .toList();
    }

    // Update Farm Activity
    @Override
    public FarmActivityResponseDTO updateActivity(
            Long activityId,
            FarmActivityUpdateRequestDTO requestDTO) {

        FarmActivity activity = farmActivityRepository.findById(activityId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Farm activity not found with ID: " + activityId));

        activity.setActivityType(requestDTO.getActivityType());
        activity.setDescription(requestDTO.getDescription());
        activity.setScheduledDate(requestDTO.getScheduledDate());
        activity.setCompletedDate(requestDTO.getCompletedDate());
        activity.setStatus(requestDTO.getStatus());
        activity.setAssignedTo(requestDTO.getAssignedTo());

        FarmActivity updatedActivity =
                farmActivityRepository.save(activity);

        return farmActivityMapper.toResponseDTO(updatedActivity);
    }

    // Delete Farm Activity
    @Override
    public void deleteActivity(Long activityId) {

        FarmActivity activity = farmActivityRepository.findById(activityId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Farm activity not found with ID: " + activityId));

        farmActivityRepository.delete(activity);
    }
}
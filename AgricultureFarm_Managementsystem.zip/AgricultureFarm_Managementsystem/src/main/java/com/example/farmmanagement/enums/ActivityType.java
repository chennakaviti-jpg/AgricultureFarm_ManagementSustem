package com.example.farmmanagement.enums;

public enum ActivityType {

	    LAND_PREPARATION,
	    PLOWING,
	    SOWING,
	    IRRIGATION,
	    FERTILIZER_APPLICATION,
	    PESTICIDE_APPLICATION,
	    WEEDING,
	    PRUNING,
	    CROP_MONITORING,
	    HARVEST_PREPARATION,
	    HARVESTING
	}
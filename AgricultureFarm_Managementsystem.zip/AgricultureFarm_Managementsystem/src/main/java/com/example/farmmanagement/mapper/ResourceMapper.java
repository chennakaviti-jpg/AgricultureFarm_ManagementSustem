package com.example.farmmanagement.mapper;

	import org.mapstruct.Mapper;
	import org.mapstruct.Mapping;
	import org.mapstruct.MappingConstants;

	import com.example.farmmanagement.DTO.request.ResourceRequestDTO;
	import com.example.farmmanagement.DTO.response.ResourceResponseDTO;
	import com.example.farmmanagement.entity.Resource;

	@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
	public interface ResourceMapper {

	    @Mapping(target = "resourceId", ignore = true)
	    @Mapping(target = "resourceUsages", ignore = true)
	    Resource toEntity(ResourceRequestDTO dto);

	    ResourceResponseDTO toResponseDTO(Resource resource);
	}
package com.example.farmmanagement.Controller;

	import java.util.List;

	import org.springframework.http.HttpStatus;
	import org.springframework.http.ResponseEntity;
	import org.springframework.web.bind.annotation.DeleteMapping;
	import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.PathVariable;
	import org.springframework.web.bind.annotation.PostMapping;
	import org.springframework.web.bind.annotation.PutMapping;
	import org.springframework.web.bind.annotation.RequestBody;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.bind.annotation.RestController;

	import com.example.farmmanagement.DTO.request.FarmRequestDTO;
	import com.example.farmmanagement.DTO.request.FarmUpdateRequestDTO;
	import com.example.farmmanagement.DTO.response.FarmResponseDTO;
	import com.example.farmmanagement.service.FarmService;

	import jakarta.validation.Valid;

	@RestController
	@RequestMapping("/api/farms")
	public class FarmController {

	    private final FarmService farmService;

	    public FarmController(FarmService farmService) {
	        this.farmService = farmService;
	    }

	    // Create a new farm
	    @PostMapping
	    public ResponseEntity<FarmResponseDTO> createFarm(
	            @Valid @RequestBody FarmRequestDTO requestDTO) {

	        FarmResponseDTO response = farmService.createFarm(requestDTO);

	        return ResponseEntity.status(HttpStatus.CREATED).body(response);
	    }

	    // Get a farm by ID
	    @GetMapping("/{farmId}")
	    public ResponseEntity<FarmResponseDTO> getFarmById(
	            @PathVariable Long farmId) {

	        FarmResponseDTO response = farmService.getFarmById(farmId);

	        return ResponseEntity.ok(response);
	    }

	    // Get all farms
	    @GetMapping
	    public ResponseEntity<List<FarmResponseDTO>> getAllFarms() {

	        List<FarmResponseDTO> response = farmService.getAllFarms();

	        return ResponseEntity.ok(response);
	    }

	    // Update a farm
	    @PutMapping("/{farmId}")
	    public ResponseEntity<FarmResponseDTO> updateFarm(
	            @PathVariable Long farmId,
	            @Valid @RequestBody FarmUpdateRequestDTO requestDTO) {

	        FarmResponseDTO response =
	                farmService.updateFarm(farmId, requestDTO);

	        return ResponseEntity.ok(response);
	    }

	    // Delete a farm
	    @DeleteMapping("/{farmId}")
	    public ResponseEntity<Void> deleteFarm(
	            @PathVariable Long farmId) {

	        farmService.deleteFarm(farmId);

	        return ResponseEntity.noContent().build();
	    }
	}
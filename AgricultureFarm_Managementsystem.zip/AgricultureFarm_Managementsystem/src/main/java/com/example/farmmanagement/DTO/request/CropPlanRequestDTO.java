package com.example.farmmanagement.DTO.request;

	import java.time.LocalDate;

	import com.example.farmmanagement.enums.Season;

	import jakarta.validation.constraints.NotNull;
	import jakarta.validation.constraints.Positive;
	import jakarta.validation.constraints.FutureOrPresent;

	public class CropPlanRequestDTO {

	    @NotNull(message = "Field ID is required")
	    @Positive(message = "Field ID must be positive")
	    private Long fieldId;

	    @NotNull(message = "Crop ID is required")
	    @Positive(message = "Crop ID must be positive")
	    private Long cropId;

	    @NotNull(message = "Season is required")
	    private Season season;

	    @NotNull(message = "Plan year is required")
	    @Positive(message = "Plan year must be positive")
	    private Integer planYear;

	    @NotNull(message = "Planned sowing date is required")
	    @FutureOrPresent(message = "Sowing date cannot be in the past")
	    private LocalDate plannedSowingDate;

	    @NotNull(message = "Planned harvest date is required")
	    private LocalDate plannedHarvestDate;

	    public CropPlanRequestDTO() {
	    }

	    public Long getFieldId() {
	        return fieldId;
	    }

	    public void setFieldId(Long fieldId) {
	        this.fieldId = fieldId;
	    }

	    public Long getCropId() {
	        return cropId;
	    }

	    public void setCropId(Long cropId) {
	        this.cropId = cropId;
	    }

	    public Season getSeason() {
	        return season;
	    }

	    public void setSeason(Season season) {
	        this.season = season;
	    }

	    public Integer getPlanYear() {
	        return planYear;
	    }

	    public void setPlanYear(Integer planYear) {
	        this.planYear = planYear;
	    }

	    public LocalDate getPlannedSowingDate() {
	        return plannedSowingDate;
	    }

	    public void setPlannedSowingDate(LocalDate plannedSowingDate) {
	        this.plannedSowingDate = plannedSowingDate;
	    }

	    public LocalDate getPlannedHarvestDate() {
	        return plannedHarvestDate;
	    }

	    public void setPlannedHarvestDate(LocalDate plannedHarvestDate) {
	        this.plannedHarvestDate = plannedHarvestDate;
	    }
	}
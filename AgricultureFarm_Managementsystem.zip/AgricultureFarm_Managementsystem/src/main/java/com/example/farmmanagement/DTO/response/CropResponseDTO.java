package com.example.farmmanagement.DTO.response;

	public class CropResponseDTO {

	    private Long cropId;
	    private String cropName;
	    private String cropCategory;
	    private Integer expectedDurationDays;
	    private String description;

	    public CropResponseDTO() {
	    }

	    public Long getCropId() {
	        return cropId;
	    }

	    public void setCropId(Long cropId) {
	        this.cropId = cropId;
	    }

	    public String getCropName() {
	        return cropName;
	    }

	    public void setCropName(String cropName) {
	        this.cropName = cropName;
	    }

	    public String getCropCategory() {
	        return cropCategory;
	    }

	    public void setCropCategory(String cropCategory) {
	        this.cropCategory = cropCategory;
	    }

	    public Integer getExpectedDurationDays() {
	        return expectedDurationDays;
	    }

	    public void setExpectedDurationDays(Integer expectedDurationDays) {
	        this.expectedDurationDays = expectedDurationDays;
	    }

	    public String getDescription() {
	        return description;
	    }

	    public void setDescription(String description) {
	        this.description = description;
	    }
	}
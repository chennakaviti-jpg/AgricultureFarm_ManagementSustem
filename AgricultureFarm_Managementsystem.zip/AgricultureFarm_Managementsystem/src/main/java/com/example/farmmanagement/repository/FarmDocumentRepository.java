package com.example.farmmanagement.repository;

	import org.springframework.data.jpa.repository.JpaRepository;
	import org.springframework.stereotype.Repository;

	import com.example.farmmanagement.entity.FarmDocument;

	@Repository
	public interface FarmDocumentRepository
	        extends JpaRepository<FarmDocument, Long> {

	}
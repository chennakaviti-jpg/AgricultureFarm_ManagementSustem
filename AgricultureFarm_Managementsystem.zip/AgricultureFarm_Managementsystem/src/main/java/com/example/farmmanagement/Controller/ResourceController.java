package com.example.farmmanagement.Controller;

	import java.util.List;

	import org.springframework.http.HttpStatus;
	import org.springframework.http.ResponseEntity;
	import org.springframework.web.bind.annotation.DeleteMapping;
	import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.PathVariable;
	import org.springframework.web.bind.annotation.PostMapping;
	import org.springframework.web.bind.annotation.PutMapping;
	import org.springframework.web.bind.annotation.RequestBody;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.bind.annotation.RestController;

	import com.example.farmmanagement.DTO.request.ResourceRequestDTO;
	import com.example.farmmanagement.DTO.request.ResourceUpdateRequestDTO;
	import com.example.farmmanagement.DTO.response.ResourceResponseDTO;
	import com.example.farmmanagement.service.ResourceService;

	import jakarta.validation.Valid;

	@RestController
	@RequestMapping("/api/resources")
	public class ResourceController {

	    private final ResourceService resourceService;

	    public ResourceController(ResourceService resourceService) {
	        this.resourceService = resourceService;
	    }

	    // Create a resource
	    @PostMapping
	    public ResponseEntity<ResourceResponseDTO> createResource(
	            @Valid @RequestBody ResourceRequestDTO requestDTO) {

	        ResourceResponseDTO response =
	                resourceService.createResource(requestDTO);

	        return ResponseEntity.status(HttpStatus.CREATED).body(response);
	    }

	    // Get a resource by ID
	    @GetMapping("/{resourceId}")
	    public ResponseEntity<ResourceResponseDTO> getResourceById(
	            @PathVariable Long resourceId) {

	        ResourceResponseDTO response =
	                resourceService.getResourceById(resourceId);

	        return ResponseEntity.ok(response);
	    }

	    // Get all resources
	    @GetMapping
	    public ResponseEntity<List<ResourceResponseDTO>> getAllResources() {

	        List<ResourceResponseDTO> response =
	                resourceService.getAllResources();

	        return ResponseEntity.ok(response);
	    }

	    // Update a resource
	    @PutMapping("/{resourceId}")
	    public ResponseEntity<ResourceResponseDTO> updateResource(
	            @PathVariable Long resourceId,
	            @Valid @RequestBody ResourceUpdateRequestDTO requestDTO) {

	        ResourceResponseDTO response =
	                resourceService.updateResource(resourceId, requestDTO);

	        return ResponseEntity.ok(response);
	    }

	    // Delete a resource
	    @DeleteMapping("/{resourceId}")
	    public ResponseEntity<Void> deleteResource(
	            @PathVariable Long resourceId) {

	        resourceService.deleteResource(resourceId);

	        return ResponseEntity.noContent().build();
	    }
	}
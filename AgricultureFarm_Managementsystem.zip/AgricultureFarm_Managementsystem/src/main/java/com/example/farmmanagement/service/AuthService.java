package com.example.farmmanagement.service;

	import org.springframework.security.authentication.BadCredentialsException;
	import org.springframework.security.crypto.password.PasswordEncoder;
	import org.springframework.stereotype.Service;
	import org.springframework.transaction.annotation.Transactional;

	import com.example.farmmanagement.DTO.request.LoginRequestDTO;
	import com.example.farmmanagement.DTO.request.RegisterRequestDTO;
	import com.example.farmmanagement.DTO.response.AuthResponseDTO;
	import com.example.farmmanagement.entity.AppUser;
	import com.example.farmmanagement.enums.UserRole;
	import com.example.farmmanagement.repository.AppUserRepository;
	import com.example.farmmanagement.security.JwtService;

	@Service
	public class AuthService {

	    private final AppUserRepository appUserRepository;
	    private final PasswordEncoder passwordEncoder;
	    private final JwtService jwtService;

	    public AuthService(
	            AppUserRepository appUserRepository,
	            PasswordEncoder passwordEncoder,
	            JwtService jwtService) {
	        this.appUserRepository = appUserRepository;
	        this.passwordEncoder = passwordEncoder;
	        this.jwtService = jwtService;
	    }

	    @Transactional
	    public AuthResponseDTO register(RegisterRequestDTO request) {

	        if (appUserRepository.existsByUsername(request.getUsername())) {
	            throw new IllegalArgumentException("Username already exists");
	        }

	        if (appUserRepository.existsByEmail(request.getEmail())) {
	            throw new IllegalArgumentException("Email already exists");
	        }

	        AppUser user = new AppUser();
	        user.setUsername(request.getUsername());
	        user.setEmail(request.getEmail());
	        user.setPassword(passwordEncoder.encode(request.getPassword()));
	        user.setRole(UserRole.FARM_WORKER);
	        user.setEnabled(true);

	        AppUser savedUser = appUserRepository.save(user);

	        String token = jwtService.generateToken(savedUser.getUsername());

	        return new AuthResponseDTO(
	                token,
	                "Bearer",
	                savedUser.getUsername(),
	                savedUser.getRole().name()
	        );
	    }

	    @Transactional(readOnly = true)
	    public AuthResponseDTO login(LoginRequestDTO request) {

	        AppUser user = appUserRepository
	                .findByUsername(request.getUsername())
	                .orElseThrow(() ->
	                        new BadCredentialsException("Invalid username or password"));

	        if (!user.isEnabled()
	                || !passwordEncoder.matches(
	                        request.getPassword(), user.getPassword())) {
	            throw new BadCredentialsException("Invalid username or password");
	        }

	        String token = jwtService.generateToken(user.getUsername());

	        return new AuthResponseDTO(
	                token,
	                "Bearer",
	                user.getUsername(),
	                user.getRole().name()
	        );
	    }
	}
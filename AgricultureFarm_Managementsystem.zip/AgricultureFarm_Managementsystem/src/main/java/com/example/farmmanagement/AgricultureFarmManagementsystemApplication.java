package com.example.farmmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class AgricultureFarmManagementsystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(
                AgricultureFarmManagementsystemApplication.class,
                args);
    }
}
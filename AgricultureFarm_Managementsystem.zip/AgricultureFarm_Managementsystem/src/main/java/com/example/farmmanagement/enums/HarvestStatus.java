package com.example.farmmanagement.enums;

public enum HarvestStatus {
	PLANNED,
	IN_PROGRESS,
	COMPLETED,
	CANCELLED
}

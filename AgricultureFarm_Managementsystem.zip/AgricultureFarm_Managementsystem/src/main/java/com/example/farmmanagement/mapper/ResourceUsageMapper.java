package com.example.farmmanagement.mapper;

	import org.mapstruct.Mapper;
	import org.mapstruct.Mapping;
	import org.mapstruct.MappingConstants;

	import com.example.farmmanagement.DTO.request.ResourceUsageRequestDTO;
	import com.example.farmmanagement.DTO.response.ResourceUsageResponseDTO;
	import com.example.farmmanagement.entity.ResourceUsage;

	@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
	public interface ResourceUsageMapper {

	    @Mapping(target = "usageId", ignore = true)
	    @Mapping(target = "activity.activityId", source = "activityId")
	    @Mapping(target = "resource.resourceId", source = "resourceId")
	    ResourceUsage toEntity(ResourceUsageRequestDTO dto);

	    @Mapping(target = "activityId", source = "activity.activityId")
	    @Mapping(target = "resourceId", source = "resource.resourceId")
	    ResourceUsageResponseDTO toResponseDTO(ResourceUsage resourceUsage);
	}
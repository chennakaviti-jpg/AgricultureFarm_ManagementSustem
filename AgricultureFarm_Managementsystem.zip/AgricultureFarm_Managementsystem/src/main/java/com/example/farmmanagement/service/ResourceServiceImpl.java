package com.example.farmmanagement.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.farmmanagement.DTO.request.ResourceRequestDTO;
import com.example.farmmanagement.DTO.request.ResourceUpdateRequestDTO;
import com.example.farmmanagement.DTO.response.ResourceResponseDTO;
import com.example.farmmanagement.entity.Resource;
import com.example.farmmanagement.exception.ResourceNotFoundException;
import com.example.farmmanagement.mapper.ResourceMapper;
import com.example.farmmanagement.repository.ResourceRepository;

@Service
@Transactional
public class ResourceServiceImpl implements ResourceService {

    private final ResourceRepository resourceRepository;
    private final ResourceMapper resourceMapper;

    public ResourceServiceImpl(
            ResourceRepository resourceRepository,
            ResourceMapper resourceMapper) {
        this.resourceRepository = resourceRepository;
        this.resourceMapper = resourceMapper;
    }

    // Create Resource
    @Override
    public ResourceResponseDTO createResource(ResourceRequestDTO requestDTO) {

        Resource resource = resourceMapper.toEntity(requestDTO);
        Resource savedResource = resourceRepository.save(resource);

        return resourceMapper.toResponseDTO(savedResource);
    }

    // Get Resource By ID
    @Override
    @Transactional(readOnly = true)
    public ResourceResponseDTO getResourceById(Long resourceId) {

        Resource resource = resourceRepository.findById(resourceId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Resource not found with ID: " + resourceId));

        return resourceMapper.toResponseDTO(resource);
    }

    // Get All Resources
    @Override
    @Transactional(readOnly = true)
    public List<ResourceResponseDTO> getAllResources() {

        return resourceRepository.findAll()
                .stream()
                .map(resourceMapper::toResponseDTO)
                .toList();
    }

    // Update Resource
    @Override
    public ResourceResponseDTO updateResource(
            Long resourceId,
            ResourceUpdateRequestDTO requestDTO) {

        Resource resource = resourceRepository.findById(resourceId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Resource not found with ID: " + resourceId));

        resource.setResourceName(requestDTO.getResourceName());
        resource.setResourceType(requestDTO.getResourceType());
        resource.setAvailableQuantity(requestDTO.getAvailableQuantity());
        resource.setUnit(requestDTO.getUnit());
        resource.setMinimumStockLevel(requestDTO.getMinimumStockLevel());
        resource.setDescription(requestDTO.getDescription());

        Resource updatedResource = resourceRepository.save(resource);

        return resourceMapper.toResponseDTO(updatedResource);
    }

    // Delete Resource
    @Override
    public void deleteResource(Long resourceId) {

        Resource resource = resourceRepository.findById(resourceId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Resource not found with ID: " + resourceId));

        resourceRepository.delete(resource);
    }
}
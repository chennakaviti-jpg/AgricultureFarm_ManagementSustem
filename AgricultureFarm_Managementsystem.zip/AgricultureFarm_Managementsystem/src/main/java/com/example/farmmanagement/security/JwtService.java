package com.example.farmmanagement.security;

	import java.nio.charset.StandardCharsets;
	import java.util.Date;

	import javax.crypto.SecretKey;

	import org.springframework.beans.factory.annotation.Value;
	import org.springframework.stereotype.Service;

	import io.jsonwebtoken.Claims;
	import io.jsonwebtoken.Jwts;
	import io.jsonwebtoken.security.Keys;

	@Service
	public class JwtService {

	    private final SecretKey secretKey;
	    private final long expirationMs;

	    public JwtService(
	            @Value("${app.jwt.secret}") String secret,
	            @Value("${app.jwt.expiration-ms}") long expirationMs) {

	        if (secret == null
	                || secret.getBytes(StandardCharsets.UTF_8).length < 32) {
	            throw new IllegalArgumentException(
	                    "JWT secret must contain at least 32 bytes");
	        }

	        this.secretKey = Keys.hmacShaKeyFor(
	                secret.getBytes(StandardCharsets.UTF_8));

	        this.expirationMs = expirationMs;
	    }

	    public String generateToken(String username) {

	        Date issuedAt = new Date();
	        Date expiration = new Date(
	                issuedAt.getTime() + expirationMs);

	        return Jwts.builder()
	                .subject(username)
	                .issuedAt(issuedAt)
	                .expiration(expiration)
	                .signWith(secretKey)
	                .compact();
	    }

	    public String extractUsername(String token) {
	        return extractAllClaims(token).getSubject();
	    }

	    public boolean isTokenValid(String token, String username) {

	        Claims claims = extractAllClaims(token);

	        return username.equals(claims.getSubject())
	                && claims.getExpiration() != null
	                && claims.getExpiration().after(new Date());
	    }

	    private Claims extractAllClaims(String token) {

	        return Jwts.parser()
	                .verifyWith(secretKey)
	                .build()
	                .parseSignedClaims(token)
	                .getPayload();
	    }
	}
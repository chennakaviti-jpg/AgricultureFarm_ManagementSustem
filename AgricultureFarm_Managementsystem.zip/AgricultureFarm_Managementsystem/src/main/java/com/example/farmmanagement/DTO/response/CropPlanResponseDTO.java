package com.example.farmmanagement.DTO.response;

	import java.time.LocalDate;

	import com.example.farmmanagement.enums.CropStatus;
	import com.example.farmmanagement.enums.Season;

	public class CropPlanResponseDTO {

	    private Long cropPlanId;
	    private Long fieldId;
	    private Long cropId;
	    private Season season;
	    private Integer planYear;
	    private LocalDate plannedSowingDate;
	    private LocalDate plannedHarvestDate;
	    private CropStatus status;

	    public CropPlanResponseDTO() {
	    }

	    public Long getCropPlanId() {
	        return cropPlanId;
	    }

	    public void setCropPlanId(Long cropPlanId) {
	        this.cropPlanId = cropPlanId;
	    }

	    public Long getFieldId() {
	        return fieldId;
	    }

	    public void setFieldId(Long fieldId) {
	        this.fieldId = fieldId;
	    }

	    public Long getCropId() {
	        return cropId;
	    }

	    public void setCropId(Long cropId) {
	        this.cropId = cropId;
	    }

	    public Season getSeason() {
	        return season;
	    }

	    public void setSeason(Season season) {
	        this.season = season;
	    }

	    public Integer getPlanYear() {
	        return planYear;
	    }

	    public void setPlanYear(Integer planYear) {
	        this.planYear = planYear;
	    }

	    public LocalDate getPlannedSowingDate() {
	        return plannedSowingDate;
	    }

	    public void setPlannedSowingDate(LocalDate plannedSowingDate) {
	        this.plannedSowingDate = plannedSowingDate;
	    }

	    public LocalDate getPlannedHarvestDate() {
	        return plannedHarvestDate;
	    }

	    public void setPlannedHarvestDate(LocalDate plannedHarvestDate) {
	        this.plannedHarvestDate = plannedHarvestDate;
	    }

	    public CropStatus getStatus() {
	        return status;
	    }

	    public void setStatus(CropStatus status) {
	        this.status = status;
	    }
	}
package com.example.farmmanagement.Controller;

	import java.util.List;

	import org.springframework.http.HttpStatus;
	import org.springframework.http.ResponseEntity;
	import org.springframework.web.bind.annotation.DeleteMapping;
	import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.PathVariable;
	import org.springframework.web.bind.annotation.PostMapping;
	import org.springframework.web.bind.annotation.PutMapping;
	import org.springframework.web.bind.annotation.RequestBody;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.bind.annotation.RestController;

	import com.example.farmmanagement.DTO.request.ResourceUsageRequestDTO;
	import com.example.farmmanagement.DTO.request.ResourceUsageUpdateRequestDTO;
	import com.example.farmmanagement.DTO.response.ResourceUsageResponseDTO;
	import com.example.farmmanagement.service.ResourceUsageService;

	import jakarta.validation.Valid;

	@RestController
	@RequestMapping("/api/resource-usages")
	public class ResourceUsageController {

	    private final ResourceUsageService resourceUsageService;

	    public ResourceUsageController(ResourceUsageService resourceUsageService) {
	        this.resourceUsageService = resourceUsageService;
	    }

	    // Record resource usage
	    @PostMapping
	    public ResponseEntity<ResourceUsageResponseDTO> createResourceUsage(
	            @Valid @RequestBody ResourceUsageRequestDTO requestDTO) {

	        ResourceUsageResponseDTO response =
	                resourceUsageService.recordResourceUsage(requestDTO);

	        return ResponseEntity.status(HttpStatus.CREATED).body(response);
	    }

	    // Get resource usage by ID
	    @GetMapping("/{usageId}")
	    public ResponseEntity<ResourceUsageResponseDTO> getResourceUsageById(
	            @PathVariable Long usageId) {

	        ResourceUsageResponseDTO response =
	                resourceUsageService.getResourceUsageById(usageId);

	        return ResponseEntity.ok(response);
	    }

	    // Get all resource usage records
	    @GetMapping
	    public ResponseEntity<List<ResourceUsageResponseDTO>> getAllResourceUsages() {

	        List<ResourceUsageResponseDTO> response =
	                resourceUsageService.getAllResourceUsages();

	        return ResponseEntity.ok(response);
	    }

	    // Update resource usage
	    @PutMapping("/{usageId}")
	    public ResponseEntity<ResourceUsageResponseDTO> updateResourceUsage(
	            @PathVariable Long usageId,
	            @Valid @RequestBody ResourceUsageUpdateRequestDTO requestDTO) {

	        ResourceUsageResponseDTO response =
	                resourceUsageService.updateResourceUsage(usageId, requestDTO);

	        return ResponseEntity.ok(response);
	    }

	    // Delete resource usage
	    @DeleteMapping("/{usageId}")
	    public ResponseEntity<Void> deleteResourceUsage(
	            @PathVariable Long usageId) {

	        resourceUsageService.deleteResourceUsage(usageId);

	        return ResponseEntity.noContent().build();
	    }
	}
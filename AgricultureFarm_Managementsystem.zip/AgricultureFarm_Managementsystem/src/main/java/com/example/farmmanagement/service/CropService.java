package com.example.farmmanagement.service;

	import java.util.List;

	import com.example.farmmanagement.DTO.request.CropRequestDTO;
	import com.example.farmmanagement.DTO.request.CropUpdateRequestDTO;
	import com.example.farmmanagement.DTO.response.CropResponseDTO;

	public interface CropService {

	    CropResponseDTO createCrop(CropRequestDTO requestDTO);

	    CropResponseDTO getCropById(Long cropId);

	    List<CropResponseDTO> getAllCrops();

	    CropResponseDTO updateCrop(
	            Long cropId,
	            CropUpdateRequestDTO requestDTO);

	    void deleteCrop(Long cropId);
	}
package com.example.farmmanagement.mapper;

	import org.mapstruct.Mapper;
	import org.mapstruct.Mapping;
	import org.mapstruct.MappingConstants;

	import com.example.farmmanagement.DTO.request.FarmActivityRequestDTO;
	import com.example.farmmanagement.DTO.response.FarmActivityResponseDTO;
	import com.example.farmmanagement.entity.FarmActivity;

	@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
	public interface FarmActivityMapper {

	    @Mapping(target = "activityId", ignore = true)
	    @Mapping(target = "cropPlan.cropPlanId", source = "cropPlanId")
	    @Mapping(target = "resourceUsages", ignore = true)
	    FarmActivity toEntity(FarmActivityRequestDTO dto);

	    @Mapping(target = "cropPlanId", source = "cropPlan.cropPlanId")
	    FarmActivityResponseDTO toResponseDTO(FarmActivity activity);
	}
package com.example.farmmanagement.DTO.request;

	import com.example.farmmanagement.enums.MeasurementUnit;

	import jakarta.validation.constraints.DecimalMin;
	import jakarta.validation.constraints.NotNull;
	import jakarta.validation.constraints.Size;

	public class ResourceUsageUpdateRequestDTO {

	    @NotNull(message = "Resource ID is required")
	    private Long resourceId;

	    @NotNull(message = "Used quantity is required")
	    @DecimalMin(value = "0.0",
	            message = "Used quantity cannot be negative")
	    private Double usedQuantity;

	    @NotNull(message = "Measurement unit is required")
	    private MeasurementUnit unit;

	    @Size(max = 500, message = "Remarks cannot exceed 500 characters")
	    private String remarks;

	    public ResourceUsageUpdateRequestDTO() {
	    }

	    public Long getResourceId() {
	        return resourceId;
	    }

	    public void setResourceId(Long resourceId) {
	        this.resourceId = resourceId;
	    }

	    public Double getUsedQuantity() {
	        return usedQuantity;
	    }

	    public void setUsedQuantity(Double usedQuantity) {
	        this.usedQuantity = usedQuantity;
	    }

	    public MeasurementUnit getUnit() {
	        return unit;
	    }

	    public void setUnit(MeasurementUnit unit) {
	        this.unit = unit;
	    }

	    public String getRemarks() {
	        return remarks;
	    }

	    public void setRemarks(String remarks) {
	        this.remarks = remarks;
	    }
	}
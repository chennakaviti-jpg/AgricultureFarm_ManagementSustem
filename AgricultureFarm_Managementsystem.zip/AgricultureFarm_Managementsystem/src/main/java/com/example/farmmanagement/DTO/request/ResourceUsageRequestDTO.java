package com.example.farmmanagement.DTO.request;

	import com.example.farmmanagement.enums.MeasurementUnit;

	import jakarta.validation.constraints.DecimalMin;
	import jakarta.validation.constraints.NotNull;
	import jakarta.validation.constraints.Positive;

	public class ResourceUsageRequestDTO {

	    @NotNull(message = "Activity ID is required")
	    @Positive(message = "Activity ID must be positive")
	    private Long activityId;

	    @NotNull(message = "Resource ID is required")
	    @Positive(message = "Resource ID must be positive")
	    private Long resourceId;

	    @NotNull(message = "Used quantity is required")
	    @DecimalMin(value = "0.0", inclusive = false,
	            message = "Used quantity must be greater than zero")
	    private Double usedQuantity;

	    @NotNull(message = "Measurement unit is required")
	    private MeasurementUnit unit;

	    private String remarks;

	    public ResourceUsageRequestDTO() {
	    }

	    public Long getActivityId() {
	        return activityId;
	    }

	    public void setActivityId(Long activityId) {
	        this.activityId = activityId;
	    }

	    public Long getResourceId() {
	        return resourceId;
	    }

	    public void setResourceId(Long resourceId) {
	        this.resourceId = resourceId;
	    }

	    public Double getUsedQuantity() {
	        return usedQuantity;
	    }

	    public void setUsedQuantity(Double usedQuantity) {
	        this.usedQuantity = usedQuantity;
	    }

	    public MeasurementUnit getUnit() {
	        return unit;
	    }

	    public void setUnit(MeasurementUnit unit) {
	        this.unit = unit;
	    }

	    public String getRemarks() {
	        return remarks;
	    }

	    public void setRemarks(String remarks) {
	        this.remarks = remarks;
	    }
	}
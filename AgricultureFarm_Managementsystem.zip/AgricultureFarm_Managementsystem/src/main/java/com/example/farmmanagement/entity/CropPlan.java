package com.example.farmmanagement.entity;

	import com.example.farmmanagement.enums.CropStatus;
	import com.example.farmmanagement.enums.Season;
	import jakarta.persistence.*;
	import jakarta.validation.constraints.NotNull;
	import jakarta.validation.constraints.Positive;

	import java.time.LocalDate;
	import java.util.ArrayList;
	import java.util.List;

	@Entity
	@Table(
	    name = "crop_plans",
	    uniqueConstraints = {
	        @UniqueConstraint(
	            name = "uk_field_season_year",
	            columnNames = {"field_id", "season", "plan_year"}
	        )
	    }
	)
	public class CropPlan {

	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long cropPlanId;

	    @ManyToOne(fetch = FetchType.LAZY, optional = false)
	    @JoinColumn(
	        name = "field_id",
	        nullable = false,
	        foreignKey = @ForeignKey(name = "fk_crop_plan_field")
	    )
	    private Field field;

	    @ManyToOne(fetch = FetchType.LAZY, optional = false)
	    @JoinColumn(
	        name = "crop_id",
	        nullable = false,
	        foreignKey = @ForeignKey(name = "fk_crop_plan_crop")
	    )
	    private Crop crop;

	    @Enumerated(EnumType.STRING)
	    @Column(nullable = false, length = 30)
	    private Season season;

	    @NotNull(message = "Plan year is required")
	    @Positive(message = "Plan year must be greater than zero")
	    @Column(name = "plan_year", nullable = false)
	    private Integer planYear;

	    @NotNull(message = "Planned sowing date is required")
	    @Column(name = "planned_sowing_date", nullable = false)
	    private LocalDate plannedSowingDate;

	    @Column(name = "planned_harvest_date")
	    private LocalDate plannedHarvestDate;

	    @Enumerated(EnumType.STRING)
	    @Column(nullable = false, length = 30)
	    private CropStatus status = CropStatus.PLANNED;

	    // One CropPlan can have many Farm Activities
	    @OneToMany(mappedBy = "cropPlan", fetch = FetchType.LAZY)
	    private List<FarmActivity> activities = new ArrayList<>();

	    // One CropPlan can have many Crop Monitoring records
	    @OneToMany(mappedBy = "cropPlan", fetch = FetchType.LAZY)
	    private List<CropMonitoring> monitoringRecords = new ArrayList<>();

	    // One CropPlan can have many Harvest records
	    @OneToMany(mappedBy = "cropPlan", fetch = FetchType.LAZY)
	    private List<Harvest> harvests = new ArrayList<>();

	    public CropPlan() {
	    }

	    public Long getCropPlanId() {
	        return cropPlanId;
	    }

	    public void setCropPlanId(Long cropPlanId) {
	        this.cropPlanId = cropPlanId;
	    }

	    public Field getField() {
	        return field;
	    }

	    public void setField(Field field) {
	        this.field = field;
	    }

	    public Crop getCrop() {
	        return crop;
	    }

	    public void setCrop(Crop crop) {
	        this.crop = crop;
	    }

	    public Season getSeason() {
	        return season;
	    }

	    public void setSeason(Season season) {
	        this.season = season;
	    }

	    public Integer getPlanYear() {
	        return planYear;
	    }

	    public void setPlanYear(Integer planYear) {
	        this.planYear = planYear;
	    }

	    public LocalDate getPlannedSowingDate() {
	        return plannedSowingDate;
	    }

	    public void setPlannedSowingDate(LocalDate plannedSowingDate) {
	        this.plannedSowingDate = plannedSowingDate;
	    }

	    public LocalDate getPlannedHarvestDate() {
	        return plannedHarvestDate;
	    }

	    public void setPlannedHarvestDate(LocalDate plannedHarvestDate) {
	        this.plannedHarvestDate = plannedHarvestDate;
	    }

	    public CropStatus getStatus() {
	        return status;
	    }

	    public void setStatus(CropStatus status) {
	        this.status = status;
	    }

	    public List<FarmActivity> getActivities() {
	        return activities;
	    }

	    public void setActivities(List<FarmActivity> activities) {
	        this.activities = activities;
	    }

	    public List<CropMonitoring> getMonitoringRecords() {
	        return monitoringRecords;
	    }

	    public void setMonitoringRecords(List<CropMonitoring> monitoringRecords) {
	        this.monitoringRecords = monitoringRecords;
	    }

	    public List<Harvest> getHarvests() {
	        return harvests;
	    }

	    public void setHarvests(List<Harvest> harvests) {
	        this.harvests = harvests;
	    }
	}
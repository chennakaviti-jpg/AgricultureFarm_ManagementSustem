package com.example.farmmanagement.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import com.example.farmmanagement.entity.Farm;
import com.example.farmmanagement.repository.FarmRepository;

@SpringBootTest(properties = "app.jwt.secret=TestOnlySecretKeyForFarmRollbackTests1234567890")
class FarmTransactionRollbackTest {

    @Autowired
    private FarmRepository farmRepository;

    @Autowired
    private PlatformTransactionManager transactionManager;

    @Test
    void transactionShouldRollbackWhenExceptionOccurs() {

        Farm existingFarm = farmRepository.findAll()
                .stream()
                .findFirst()
                .orElseThrow(() -> new AssertionError(
                        "Create a farm record before running this test"));

        Long farmId = existingFarm.getFarmId();
        String originalName = existingFarm.getFarmName();

        TransactionTemplate transactionTemplate =
                new TransactionTemplate(transactionManager);

        assertThrows(RuntimeException.class, () ->
                transactionTemplate.executeWithoutResult(status -> {

                    Farm farm = farmRepository.findById(farmId)
                            .orElseThrow();

                    farm.setFarmName(originalName + "_TEST");

                    farmRepository.saveAndFlush(farm);

                    throw new RuntimeException("Simulated failure");
                }));

        Farm farmAfterRollback = farmRepository.findById(farmId)
                .orElseThrow();

        assertEquals(
                originalName,
                farmAfterRollback.getFarmName(),
                "Farm name should remain unchanged after rollback");
    }
}
package com.example.farmmanagement.DTO.request;

	import com.example.farmmanagement.enums.MeasurementUnit;
	import com.example.farmmanagement.enums.ResourceType;

	import jakarta.validation.constraints.DecimalMin;
	import jakarta.validation.constraints.NotBlank;
	import jakarta.validation.constraints.NotNull;
	import jakarta.validation.constraints.PositiveOrZero;
	import jakarta.validation.constraints.Size;

	public class ResourceRequestDTO {

	    @NotBlank(message = "Resource name is required")
	    @Size(max = 100, message = "Resource name cannot exceed 100 characters")
	    private String resourceName;

	    @NotNull(message = "Resource type is required")
	    private ResourceType resourceType;

	    @NotNull(message = "Available quantity is required")
	    @PositiveOrZero(message = "Available quantity cannot be negative")
	    private Double availableQuantity;

	    @NotNull(message = "Measurement unit is required")
	    private MeasurementUnit unit;

	    @NotNull(message = "Minimum stock level is required")
	    @DecimalMin(value = "0.0", message = "Minimum stock level cannot be negative")
	    private Double minimumStockLevel;

	    private String description;

	    public ResourceRequestDTO() {
	    }

	    public String getResourceName() {
	        return resourceName;
	    }

	    public void setResourceName(String resourceName) {
	        this.resourceName = resourceName;
	    }

	    public ResourceType getResourceType() {
	        return resourceType;
	    }

	    public void setResourceType(ResourceType resourceType) {
	        this.resourceType = resourceType;
	    }

	    public Double getAvailableQuantity() {
	        return availableQuantity;
	    }

	    public void setAvailableQuantity(Double availableQuantity) {
	        this.availableQuantity = availableQuantity;
	    }

	    public MeasurementUnit getUnit() {
	        return unit;
	    }

	    public void setUnit(MeasurementUnit unit) {
	        this.unit = unit;
	    }

	    public Double getMinimumStockLevel() {
	        return minimumStockLevel;
	    }

	    public void setMinimumStockLevel(Double minimumStockLevel) {
	        this.minimumStockLevel = minimumStockLevel;
	    }

	    public String getDescription() {
	        return description;
	    }

	    public void setDescription(String description) {
	        this.description = description;
	    }
	}
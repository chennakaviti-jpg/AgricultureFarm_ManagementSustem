package com.example.farmmanagement.Controller;

	import java.util.List;

	import org.springframework.http.HttpStatus;
	import org.springframework.http.ResponseEntity;
	import org.springframework.web.bind.annotation.DeleteMapping;
	import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.PathVariable;
	import org.springframework.web.bind.annotation.PostMapping;
	import org.springframework.web.bind.annotation.PutMapping;
	import org.springframework.web.bind.annotation.RequestBody;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.bind.annotation.RestController;

	import com.example.farmmanagement.DTO.request.CropRequestDTO;
	import com.example.farmmanagement.DTO.request.CropUpdateRequestDTO;
	import com.example.farmmanagement.DTO.response.CropResponseDTO;
	import com.example.farmmanagement.service.CropService;

	import jakarta.validation.Valid;

	@RestController
	@RequestMapping("/api/crops")
	public class CropController {

	    private final CropService cropService;

	    public CropController(CropService cropService) {
	        this.cropService = cropService;
	    }

	    // Create a new crop
	    @PostMapping
	    public ResponseEntity<CropResponseDTO> createCrop(
	            @Valid @RequestBody CropRequestDTO requestDTO) {

	        CropResponseDTO response = cropService.createCrop(requestDTO);

	        return ResponseEntity.status(HttpStatus.CREATED).body(response);
	    }

	    // Get a crop by ID
	    @GetMapping("/{cropId}")
	    public ResponseEntity<CropResponseDTO> getCropById(
	            @PathVariable Long cropId) {

	        CropResponseDTO response = cropService.getCropById(cropId);

	        return ResponseEntity.ok(response);
	    }

	    // Get all crops
	    @GetMapping
	    public ResponseEntity<List<CropResponseDTO>> getAllCrops() {

	        List<CropResponseDTO> response = cropService.getAllCrops();

	        return ResponseEntity.ok(response);
	    }

	    // Update a crop
	    @PutMapping("/{cropId}")
	    public ResponseEntity<CropResponseDTO> updateCrop(
	            @PathVariable Long cropId,
	            @Valid @RequestBody CropUpdateRequestDTO requestDTO) {

	        CropResponseDTO response =
	                cropService.updateCrop(cropId, requestDTO);

	        return ResponseEntity.ok(response);
	    }

	    // Delete a crop
	    @DeleteMapping("/{cropId}")
	    public ResponseEntity<Void> deleteCrop(
	            @PathVariable Long cropId) {

	        cropService.deleteCrop(cropId);

	        return ResponseEntity.noContent().build();
	    }
	}
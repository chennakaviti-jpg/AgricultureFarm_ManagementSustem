package com.example.farmmanagement.DTO.request;

	import jakarta.validation.constraints.NotBlank;
	import jakarta.validation.constraints.NotNull;
	import jakarta.validation.constraints.Positive;
	import jakarta.validation.constraints.Size;

	public class CropUpdateRequestDTO {

	    @NotBlank(message = "Crop name is required")
	    @Size(max = 100, message = "Crop name cannot exceed 100 characters")
	    private String cropName;

	    @NotBlank(message = "Crop category is required")
	    @Size(max = 100, message = "Crop category cannot exceed 100 characters")
	    private String cropCategory;

	    @NotNull(message = "Expected duration is required")
	    @Positive(message = "Expected duration must be greater than zero")
	    private Integer expectedDurationDays;

	    private String description;

	    public CropUpdateRequestDTO() {
	    }

	    public String getCropName() {
	        return cropName;
	    }

	    public void setCropName(String cropName) {
	        this.cropName = cropName;
	    }

	    public String getCropCategory() {
	        return cropCategory;
	    }

	    public void setCropCategory(String cropCategory) {
	        this.cropCategory = cropCategory;
	    }

	    public Integer getExpectedDurationDays() {
	        return expectedDurationDays;
	    }

	    public void setExpectedDurationDays(Integer expectedDurationDays) {
	        this.expectedDurationDays = expectedDurationDays;
	    }

	    public String getDescription() {
	        return description;
	    }

	    public void setDescription(String description) {
	        this.description = description;
	    }
	}
package com.example.farmmanagement.mapper;

	import org.mapstruct.Mapper;
	import org.mapstruct.Mapping;
	import org.mapstruct.MappingConstants;

	import com.example.farmmanagement.DTO.request.HarvestRequestDTO;
	import com.example.farmmanagement.DTO.response.HarvestResponseDTO;
	import com.example.farmmanagement.entity.Harvest;

	@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
	public interface HarvestMapper {

	    @Mapping(target = "harvestId", ignore = true)
	    @Mapping(target = "cropPlan.cropPlanId", source = "cropPlanId")
	    Harvest toEntity(HarvestRequestDTO dto);

	    @Mapping(target = "cropPlanId", source = "cropPlan.cropPlanId")
	    HarvestResponseDTO toResponseDTO(Harvest harvest);
	}
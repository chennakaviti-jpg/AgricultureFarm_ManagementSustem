package com.example.farmmanagement.service;

	import java.util.List;

	import org.springframework.stereotype.Service;
	import org.springframework.transaction.annotation.Transactional;

	import com.example.farmmanagement.DTO.request.ResourceUsageRequestDTO;
	import com.example.farmmanagement.DTO.request.ResourceUsageUpdateRequestDTO;
	import com.example.farmmanagement.DTO.response.ResourceUsageResponseDTO;
	import com.example.farmmanagement.entity.ResourceUsage;
	import com.example.farmmanagement.exception.ResourceNotFoundException;
	import com.example.farmmanagement.mapper.ResourceUsageMapper;
	import com.example.farmmanagement.repository.ResourceUsageRepository;

	@Service
	@Transactional
	public class ResourceUsageServiceImpl implements ResourceUsageService {

	    private final ResourceUsageRepository resourceUsageRepository;
	    private final ResourceUsageMapper resourceUsageMapper;

	    public ResourceUsageServiceImpl(
	            ResourceUsageRepository resourceUsageRepository,
	            ResourceUsageMapper resourceUsageMapper) {
	        this.resourceUsageRepository = resourceUsageRepository;
	        this.resourceUsageMapper = resourceUsageMapper;
	    }

	    // Record Resource Usage
	    @Override
	    public ResourceUsageResponseDTO recordResourceUsage(
	            ResourceUsageRequestDTO requestDTO) {

	        ResourceUsage usage = resourceUsageMapper.toEntity(requestDTO);
	        ResourceUsage savedUsage = resourceUsageRepository.save(usage);

	        return resourceUsageMapper.toResponseDTO(savedUsage);
	    }

	    // Get Resource Usage By ID
	    @Override
	    @Transactional(readOnly = true)
	    public ResourceUsageResponseDTO getResourceUsageById(Long usageId) {

	        ResourceUsage usage = resourceUsageRepository.findById(usageId)
	                .orElseThrow(() -> new ResourceNotFoundException(
	                        "Resource usage not found with ID: " + usageId));

	        return resourceUsageMapper.toResponseDTO(usage);
	    }

	    // Get All Resource Usages
	    @Override
	    @Transactional(readOnly = true)
	    public List<ResourceUsageResponseDTO> getAllResourceUsages() {

	        return resourceUsageRepository.findAll()
	                .stream()
	                .map(resourceUsageMapper::toResponseDTO)
	                .toList();
	    }

	    // Update Resource Usage
	    @Override
	    public ResourceUsageResponseDTO updateResourceUsage(
	            Long usageId,
	            ResourceUsageUpdateRequestDTO requestDTO) {

	        ResourceUsage usage = resourceUsageRepository.findById(usageId)
	                .orElseThrow(() -> new ResourceNotFoundException(
	                        "Resource usage not found with ID: " + usageId));

	        usage.setUsedQuantity(requestDTO.getUsedQuantity());
	        usage.setUnit(requestDTO.getUnit());
	        usage.setRemarks(requestDTO.getRemarks());

	        ResourceUsage updatedUsage = resourceUsageRepository.save(usage);

	        return resourceUsageMapper.toResponseDTO(updatedUsage);
	    }

	    // Delete Resource Usage
	    @Override
	    public void deleteResourceUsage(Long usageId) {

	        ResourceUsage usage = resourceUsageRepository.findById(usageId)
	                .orElseThrow(() -> new ResourceNotFoundException(
	                        "Resource usage not found with ID: " + usageId));

	        resourceUsageRepository.delete(usage);
	    }
	}
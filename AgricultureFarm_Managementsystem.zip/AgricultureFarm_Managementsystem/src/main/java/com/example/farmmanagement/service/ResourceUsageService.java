package com.example.farmmanagement.service;

	import java.util.List;
	import com.example.farmmanagement.DTO.request.ResourceUsageRequestDTO;
	import com.example.farmmanagement.DTO.request.ResourceUsageUpdateRequestDTO;
	import com.example.farmmanagement.DTO.response.ResourceUsageResponseDTO;

	public interface ResourceUsageService {

	    ResourceUsageResponseDTO recordResourceUsage(
	            ResourceUsageRequestDTO requestDTO);

	    ResourceUsageResponseDTO getResourceUsageById(Long usageId);

	    List<ResourceUsageResponseDTO> getAllResourceUsages();

	    ResourceUsageResponseDTO updateResourceUsage(
	            Long usageId,
	            ResourceUsageUpdateRequestDTO requestDTO);

	    void deleteResourceUsage(Long usageId);
	}
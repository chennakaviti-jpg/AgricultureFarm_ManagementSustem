package com.example.farmmanagement.repository;

	import org.springframework.data.jpa.repository.JpaRepository;
	import org.springframework.stereotype.Repository;

	import com.example.farmmanagement.entity.Farmer;

	@Repository
	public interface FarmerRepository extends JpaRepository<Farmer, Long> {

	}
package com.example.farmmanagement.service;

	import java.util.List;
	import com.example.farmmanagement.DTO.request.HarvestRequestDTO;
	import com.example.farmmanagement.DTO.request.HarvestUpdateRequestDTO;
	import com.example.farmmanagement.DTO.response.HarvestResponseDTO;

	public interface HarvestService {

	    HarvestResponseDTO recordHarvest(HarvestRequestDTO requestDTO);

	    HarvestResponseDTO getHarvestById(Long harvestId);

	    List<HarvestResponseDTO> getAllHarvests();

	    HarvestResponseDTO updateHarvest(
	            Long harvestId,
	            HarvestUpdateRequestDTO requestDTO);

	    void deleteHarvest(Long harvestId);
	}
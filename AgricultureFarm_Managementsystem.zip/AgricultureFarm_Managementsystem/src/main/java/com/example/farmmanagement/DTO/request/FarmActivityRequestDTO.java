package com.example.farmmanagement.DTO.request;

	import java.time.LocalDate;

	import com.example.farmmanagement.enums.ActivityType;

	import jakarta.validation.constraints.NotBlank;
	import jakarta.validation.constraints.NotNull;
	import jakarta.validation.constraints.Positive;
	import jakarta.validation.constraints.Size;

	public class FarmActivityRequestDTO {

	    @NotNull(message = "Crop plan ID is required")
	    @Positive(message = "Crop plan ID must be positive")
	    private Long cropPlanId;

	    @NotNull(message = "Activity type is required")
	    private ActivityType activityType;

	    @NotBlank(message = "Activity description is required")
	    @Size(max = 500, message = "Description cannot exceed 500 characters")
	    private String description;

	    @NotNull(message = "Scheduled date is required")
	    private LocalDate scheduledDate;

	    @Size(max = 100, message = "Assigned person cannot exceed 100 characters")
	    private String assignedTo;

	    public FarmActivityRequestDTO() {
	    }

	    public Long getCropPlanId() {
	        return cropPlanId;
	    }

	    public void setCropPlanId(Long cropPlanId) {
	        this.cropPlanId = cropPlanId;
	    }

	    public ActivityType getActivityType() {
	        return activityType;
	    }

	    public void setActivityType(ActivityType activityType) {
	        this.activityType = activityType;
	    }

	    public String getDescription() {
	        return description;
	    }

	    public void setDescription(String description) {
	        this.description = description;
	    }

	    public LocalDate getScheduledDate() {
	        return scheduledDate;
	    }

	    public void setScheduledDate(LocalDate scheduledDate) {
	        this.scheduledDate = scheduledDate;
	    }

	    public String getAssignedTo() {
	        return assignedTo;
	    }

	    public void setAssignedTo(String assignedTo) {
	        this.assignedTo = assignedTo;
	    }
	}
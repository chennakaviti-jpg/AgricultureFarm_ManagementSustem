package com.example.farmmanagement.DTO.request;

	import java.time.LocalDate;

	import jakarta.validation.constraints.NotBlank;
	import jakarta.validation.constraints.NotNull;
	import jakarta.validation.constraints.Positive;
	import jakarta.validation.constraints.Size;

	public class CropMonitoringRequestDTO {

	    @NotNull(message = "Crop plan ID is required")
	    @Positive(message = "Crop plan ID must be positive")
	    private Long cropPlanId;

	    @NotNull(message = "Monitoring date is required")
	    private LocalDate monitoringDate;

	    @NotBlank(message = "Growth stage is required")
	    @Size(max = 100, message = "Growth stage cannot exceed 100 characters")
	    private String growthStage;

	    @NotBlank(message = "Health status is required")
	    @Size(max = 100, message = "Health status cannot exceed 100 characters")
	    private String healthStatus;

	    private boolean pestDetected;

	    private boolean diseaseDetected;

	    private String observations;

	    public CropMonitoringRequestDTO() {
	    }

	    public Long getCropPlanId() {
	        return cropPlanId;
	    }

	    public void setCropPlanId(Long cropPlanId) {
	        this.cropPlanId = cropPlanId;
	    }

	    public LocalDate getMonitoringDate() {
	        return monitoringDate;
	    }

	    public void setMonitoringDate(LocalDate monitoringDate) {
	        this.monitoringDate = monitoringDate;
	    }

	    public String getGrowthStage() {
	        return growthStage;
	    }

	    public void setGrowthStage(String growthStage) {
	        this.growthStage = growthStage;
	    }

	    public String getHealthStatus() {
	        return healthStatus;
	    }

	    public void setHealthStatus(String healthStatus) {
	        this.healthStatus = healthStatus;
	    }

	    public boolean isPestDetected() {
	        return pestDetected;
	    }

	    public void setPestDetected(boolean pestDetected) {
	        this.pestDetected = pestDetected;
	    }

	    public boolean isDiseaseDetected() {
	        return diseaseDetected;
	    }

	    public void setDiseaseDetected(boolean diseaseDetected) {
	        this.diseaseDetected = diseaseDetected;
	    }

	    public String getObservations() {
	        return observations;
	    }

	    public void setObservations(String observations) {
	        this.observations = observations;
	    }
	}
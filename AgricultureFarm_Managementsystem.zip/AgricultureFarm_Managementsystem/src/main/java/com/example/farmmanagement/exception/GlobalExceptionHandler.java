package com.example.farmmanagement.exception;

	import java.time.LocalDateTime;
	import java.util.HashMap;
	import java.util.Map;

	import org.springframework.dao.DataIntegrityViolationException;
	import org.springframework.http.HttpStatus;
	import org.springframework.http.ResponseEntity;
	import org.springframework.security.access.AccessDeniedException;
	import org.springframework.security.authentication.BadCredentialsException;
	import org.springframework.web.bind.MethodArgumentNotValidException;
	import org.springframework.web.bind.annotation.ExceptionHandler;
	import org.springframework.web.bind.annotation.RestControllerAdvice;
	import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
	import org.springframework.web.multipart.MaxUploadSizeExceededException;

	@RestControllerAdvice
	public class GlobalExceptionHandler {

	    // 1. Resource Not Found - 404
	    @ExceptionHandler(ResourceNotFoundException.class)
	    public ResponseEntity<Map<String, Object>> handleResourceNotFound(
	            ResourceNotFoundException ex) {

	        return buildResponse(
	                HttpStatus.NOT_FOUND,
	                ex.getMessage());
	    }

	    // 2. Validation Errors - 400
	    @ExceptionHandler(MethodArgumentNotValidException.class)
	    public ResponseEntity<Map<String, Object>> handleValidationErrors(
	            MethodArgumentNotValidException ex) {

	        Map<String, String> fieldErrors = new HashMap<>();

	        ex.getBindingResult().getFieldErrors().forEach(error ->
	                fieldErrors.put(
	                        error.getField(),
	                        error.getDefaultMessage()));

	        Map<String, Object> body = createResponse(
	                HttpStatus.BAD_REQUEST,
	                "Validation failed");

	        body.put("fieldErrors", fieldErrors);

	        return ResponseEntity.badRequest().body(body);
	    }

	    // 3. Invalid Arguments - 400
	    @ExceptionHandler(IllegalArgumentException.class)
	    public ResponseEntity<Map<String, Object>> handleIllegalArgument(
	            IllegalArgumentException ex) {

	        return buildResponse(
	                HttpStatus.BAD_REQUEST,
	                ex.getMessage());
	    }

	    // 4. Database Constraint Violation - 409
	    @ExceptionHandler(DataIntegrityViolationException.class)
	    public ResponseEntity<Map<String, Object>> handleDataIntegrityViolation(
	            DataIntegrityViolationException ex) {

	        return buildResponse(
	                HttpStatus.CONFLICT,
	                "The operation conflicts with existing data or a database constraint.");
	    }

	    // 5. Invalid Login Credentials - 401
	    @ExceptionHandler(BadCredentialsException.class)
	    public ResponseEntity<Map<String, Object>> handleBadCredentials(
	            BadCredentialsException ex) {

	        return buildResponse(
	                HttpStatus.UNAUTHORIZED,
	                "Invalid username or password");
	    }

	    // 6. Access Denied - 403
	    @ExceptionHandler(AccessDeniedException.class)
	    public ResponseEntity<Map<String, Object>> handleAccessDenied(
	            AccessDeniedException ex) {

	        return buildResponse(
	                HttpStatus.FORBIDDEN,
	                "You do not have permission to access this resource.");
	    }

	    // 7. Uploaded File Too Large - 413
	    @ExceptionHandler(MaxUploadSizeExceededException.class)
	    public ResponseEntity<Map<String, Object>> handleMaxUploadSizeExceeded(
	            MaxUploadSizeExceededException ex) {

	        return buildResponse(
	                HttpStatus.PAYLOAD_TOO_LARGE,
	                "The uploaded file exceeds the permitted size.");
	    }

	    // 8. Unexpected Errors - 500
	    @ExceptionHandler(Exception.class)
	    public ResponseEntity<Map<String, Object>> handleGeneralException(
	            Exception ex) {

	        return buildResponse(
	                HttpStatus.INTERNAL_SERVER_ERROR,
	                "An unexpected error occurred. Please try again later.");
	    }
	 // Handle Duplicate Resource - 409 Conflict
	    @ExceptionHandler(DuplicateResourceException.class)
	    public ResponseEntity<Map<String, Object>> handleDuplicateResource(
	            DuplicateResourceException ex) {

	        return buildResponse(
	                HttpStatus.CONFLICT,
	                ex.getMessage());
	    }
	    // Common response builder
	    private ResponseEntity<Map<String, Object>> buildResponse(
	            HttpStatus status,
	            String message) {

	        return ResponseEntity
	                .status(status)
	                .body(createResponse(status, message));
	    }

	    // Standard response structure
	    private Map<String, Object> createResponse(
	            HttpStatus status,
	            String message) {

	        Map<String, Object> body = new HashMap<>();

	        body.put("timestamp", LocalDateTime.now());
	        body.put("status", status.value());
	        body.put("error", status.getReasonPhrase());
	        body.put("message", message);

	        return body;
	    }
	}
package com.example.farmmanagement.DTO.response;

	import com.example.farmmanagement.enums.MeasurementUnit;

	public class ResourceUsageResponseDTO {

	    private Long usageId;
	    private Long activityId;
	    private Long resourceId;
	    private Double usedQuantity;
	    private MeasurementUnit unit;
	    private String remarks;

	    public ResourceUsageResponseDTO() {
	    }

	    public Long getUsageId() {
	        return usageId;
	    }

	    public void setUsageId(Long usageId) {
	        this.usageId = usageId;
	    }

	    public Long getActivityId() {
	        return activityId;
	    }

	    public void setActivityId(Long activityId) {
	        this.activityId = activityId;
	    }

	    public Long getResourceId() {
	        return resourceId;
	    }

	    public void setResourceId(Long resourceId) {
	        this.resourceId = resourceId;
	    }

	    public Double getUsedQuantity() {
	        return usedQuantity;
	    }

	    public void setUsedQuantity(Double usedQuantity) {
	        this.usedQuantity = usedQuantity;
	    }

	    public MeasurementUnit getUnit() {
	        return unit;
	    }

	    public void setUnit(MeasurementUnit unit) {
	        this.unit = unit;
	    }

	    public String getRemarks() {
	        return remarks;
	    }

	    public void setRemarks(String remarks) {
	        this.remarks = remarks;
	    }
	}
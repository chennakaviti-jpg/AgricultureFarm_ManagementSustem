package com.example.farmmanagement.enums;

public enum ActivityStatus {
    PLANNED,
    IN_PROGRESS,
    COMPLETED,
    CANCELLED
}

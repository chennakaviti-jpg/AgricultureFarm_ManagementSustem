package com.example.farmmanagement.DTO.request;

	import jakarta.validation.constraints.Email;
	import jakarta.validation.constraints.NotBlank;
	import jakarta.validation.constraints.Pattern;
	import jakarta.validation.constraints.Size;

	public class FarmerRequestDTO {

	    @NotBlank(message = "Farmer name is required")
	    @Size(min = 3, max = 100,
	          message = "Farmer name must contain 3 to 100 characters")
	    private String name;

	    @NotBlank(message = "Phone number is required")
	    @Pattern(regexp = "^[0-9]{10}$",
	             message = "Phone number must contain exactly 10 digits")
	    private String phone;

	    @NotBlank(message = "Email is required")
	    @Email(message = "Please provide a valid email address")
	    private String email;

	    @NotBlank(message = "Address is required")
	    @Size(max = 255, message = "Address cannot exceed 255 characters")
	    private String address;

	    public FarmerRequestDTO() {
	    }

	    public String getName() {
	        return name;
	    }

	    public void setName(String name) {
	        this.name = name;
	    }

	    public String getPhone() {
	        return phone;
	    }

	    public void setPhone(String phone) {
	        this.phone = phone;
	    }

	    public String getEmail() {
	        return email;
	    }

	    public void setEmail(String email) {
	        this.email = email;
	    }

	    public String getAddress() {
	        return address;
	    }

	    public void setAddress(String address) {
	        this.address = address;
	    }
	}
package com.example.farmmanagement.DTO.request;

	import jakarta.validation.constraints.Email;
	import jakarta.validation.constraints.NotBlank;
	import jakarta.validation.constraints.Size;

	public class RegisterRequestDTO {

	    @NotBlank(message = "Username is required")
	    @Size(min = 4, max = 50, message = "Username must contain 4 to 50 characters")
	    private String username;

	    @NotBlank(message = "Email is required")
	    @Email(message = "Enter a valid email address")
	    @Size(max = 150, message = "Email cannot exceed 150 characters")
	    private String email;

	    @NotBlank(message = "Password is required")
	    @Size(min = 8, max = 72, message = "Password must contain 8 to 72 characters")
	    private String password;

	    public RegisterRequestDTO() {
	    }

	    public String getUsername() {
	        return username;
	    }

	    public void setUsername(String username) {
	        this.username = username;
	    }

	    public String getEmail() {
	        return email;
	    }

	    public void setEmail(String email) {
	        this.email = email;
	    }

	    public String getPassword() {
	        return password;
	    }

	    public void setPassword(String password) {
	        this.password = password;
	    }
	}
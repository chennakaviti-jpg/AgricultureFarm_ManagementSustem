package com.example.farmmanagement.service;

import java.util.List;

import org.springframework.core.io.Resource;
import org.springframework.web.multipart.MultipartFile;

import com.example.farmmanagement.DTO.request.FarmDocumentRequestDTO;
import com.example.farmmanagement.DTO.request.FarmDocumentUpdateRequestDTO;
import com.example.farmmanagement.DTO.response.FarmDocumentResponseDTO;

public interface FarmDocumentService {

    FarmDocumentResponseDTO createDocument(
            FarmDocumentRequestDTO requestDTO);

    List<FarmDocumentResponseDTO> getAllDocuments();

    FarmDocumentResponseDTO getDocumentById(Long documentId);

    FarmDocumentResponseDTO updateDocument(
            Long documentId,
            FarmDocumentUpdateRequestDTO requestDTO);

    void deleteDocument(Long documentId);

    FarmDocumentResponseDTO uploadDocument(
            Long farmId,
            com.example.farmmanagement.enums.DocumentType documentType,
            String description,
            MultipartFile file);

    Resource downloadDocument(Long documentId);
}
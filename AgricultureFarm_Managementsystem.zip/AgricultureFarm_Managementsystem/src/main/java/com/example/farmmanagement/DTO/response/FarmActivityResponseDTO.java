package com.example.farmmanagement.DTO.response;

	import java.time.LocalDate;

	import com.example.farmmanagement.enums.ActivityStatus;
	import com.example.farmmanagement.enums.ActivityType;

	public class FarmActivityResponseDTO {

	    private Long activityId;
	    private Long cropPlanId;
	    private ActivityType activityType;
	    private String description;
	    private LocalDate scheduledDate;
	    private LocalDate completedDate;
	    private ActivityStatus status;
	    private String assignedTo;

	    public FarmActivityResponseDTO() {
	    }

	    public Long getActivityId() {
	        return activityId;
	    }

	    public void setActivityId(Long activityId) {
	        this.activityId = activityId;
	    }

	    public Long getCropPlanId() {
	        return cropPlanId;
	    }

	    public void setCropPlanId(Long cropPlanId) {
	        this.cropPlanId = cropPlanId;
	    }

	    public ActivityType getActivityType() {
	        return activityType;
	    }

	    public void setActivityType(ActivityType activityType) {
	        this.activityType = activityType;
	    }

	    public String getDescription() {
	        return description;
	    }

	    public void setDescription(String description) {
	        this.description = description;
	    }

	    public LocalDate getScheduledDate() {
	        return scheduledDate;
	    }

	    public void setScheduledDate(LocalDate scheduledDate) {
	        this.scheduledDate = scheduledDate;
	    }

	    public LocalDate getCompletedDate() {
	        return completedDate;
	    }

	    public void setCompletedDate(LocalDate completedDate) {
	        this.completedDate = completedDate;
	    }

	    public ActivityStatus getStatus() {
	        return status;
	    }

	    public void setStatus(ActivityStatus status) {
	        this.status = status;
	    }

	    public String getAssignedTo() {
	        return assignedTo;
	    }

	    public void setAssignedTo(String assignedTo) {
	        this.assignedTo = assignedTo;
	    }
	}
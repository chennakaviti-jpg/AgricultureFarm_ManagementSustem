package com.example.farmmanagement.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.farmmanagement.DTO.request.CropPlanRequestDTO;
import com.example.farmmanagement.DTO.request.CropPlanUpdateRequestDTO;
import com.example.farmmanagement.DTO.response.CropPlanResponseDTO;
import com.example.farmmanagement.entity.CropPlan;
import com.example.farmmanagement.exception.ResourceNotFoundException;
import com.example.farmmanagement.mapper.CropPlanMapper;
import com.example.farmmanagement.repository.CropPlanRepository;

@Service
@Transactional
public class CropPlanServiceImpl implements CropPlanService {

    private final CropPlanRepository cropPlanRepository;
    private final CropPlanMapper cropPlanMapper;

    public CropPlanServiceImpl(
            CropPlanRepository cropPlanRepository,
            CropPlanMapper cropPlanMapper) {
        this.cropPlanRepository = cropPlanRepository;
        this.cropPlanMapper = cropPlanMapper;
    }

    // Create Crop Plan
    @Override
    public CropPlanResponseDTO createCropPlan(
            CropPlanRequestDTO requestDTO) {

        CropPlan cropPlan = cropPlanMapper.toEntity(requestDTO);
        CropPlan savedCropPlan = cropPlanRepository.save(cropPlan);

        return cropPlanMapper.toResponseDTO(savedCropPlan);
    }

    // Get Crop Plan By ID
    @Override
    @Transactional(readOnly = true)
    public CropPlanResponseDTO getCropPlanById(Long cropPlanId) {

        CropPlan cropPlan = cropPlanRepository.findById(cropPlanId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Crop plan not found with ID: " + cropPlanId));

        return cropPlanMapper.toResponseDTO(cropPlan);
    }

    // Get All Crop Plans
    @Override
    @Transactional(readOnly = true)
    public List<CropPlanResponseDTO> getAllCropPlans() {

        return cropPlanRepository.findAll()
                .stream()
                .map(cropPlanMapper::toResponseDTO)
                .toList();
    }

    // Update Crop Plan
    @Override
    public CropPlanResponseDTO updateCropPlan(
            Long cropPlanId,
            CropPlanUpdateRequestDTO requestDTO) {

        CropPlan cropPlan = cropPlanRepository.findById(cropPlanId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Crop plan not found with ID: " + cropPlanId));

        cropPlan.setSeason(requestDTO.getSeason());
        cropPlan.setPlanYear(requestDTO.getPlanYear());
        cropPlan.setPlannedSowingDate(
                requestDTO.getPlannedSowingDate());
        cropPlan.setPlannedHarvestDate(
                requestDTO.getPlannedHarvestDate());
        cropPlan.setStatus(requestDTO.getStatus());

        CropPlan updatedCropPlan = cropPlanRepository.save(cropPlan);

        return cropPlanMapper.toResponseDTO(updatedCropPlan);
    }

    // Delete Crop Plan
    @Override
    public void deleteCropPlan(Long cropPlanId) {

        CropPlan cropPlan = cropPlanRepository.findById(cropPlanId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Crop plan not found with ID: " + cropPlanId));

        cropPlanRepository.delete(cropPlan);
    }
}
package com.example.farmmanagement.mapper;

	import org.mapstruct.Mapper;
	import org.mapstruct.Mapping;
	import org.mapstruct.MappingConstants;

	import com.example.farmmanagement.DTO.request.FarmDocumentRequestDTO;
	import com.example.farmmanagement.DTO.response.FarmDocumentResponseDTO;
	import com.example.farmmanagement.entity.FarmDocument;

	@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
	public interface FarmDocumentMapper {

	    @Mapping(target = "documentId", ignore = true)
	    @Mapping(target = "farm.farmId", source = "farmId")
	    @Mapping(target = "storedFileName", ignore = true)
	    @Mapping(target = "uploadedAt", ignore = true)
	    FarmDocument toEntity(FarmDocumentRequestDTO dto);

	    @Mapping(target = "farmId", source = "farm.farmId")
	    FarmDocumentResponseDTO toResponseDTO(FarmDocument document);
	}
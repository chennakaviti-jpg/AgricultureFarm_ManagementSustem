package com.example.farmmanagement.mapper;

	import org.mapstruct.Mapper;
	import org.mapstruct.MappingConstants;

	import com.example.farmmanagement.DTO.request.FarmerRequestDTO;
	import com.example.farmmanagement.DTO.response.FarmerResponseDTO;
	import com.example.farmmanagement.entity.Farmer;

	@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
	public interface FarmerMapper {

	    Farmer toEntity(FarmerRequestDTO dto);

	    FarmerResponseDTO toResponseDTO(Farmer farmer);
	}
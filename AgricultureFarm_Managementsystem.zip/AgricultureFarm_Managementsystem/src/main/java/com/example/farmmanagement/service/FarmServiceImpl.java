package com.example.farmmanagement.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.farmmanagement.DTO.request.FarmRequestDTO;
import com.example.farmmanagement.DTO.request.FarmUpdateRequestDTO;
import com.example.farmmanagement.DTO.response.FarmResponseDTO;
import com.example.farmmanagement.entity.Farm;
import com.example.farmmanagement.exception.ResourceNotFoundException;
import com.example.farmmanagement.mapper.FarmMapper;
import com.example.farmmanagement.repository.FarmRepository;

@Service
public class FarmServiceImpl implements FarmService {

    private final FarmRepository farmRepository;
    private final FarmMapper farmMapper;

    public FarmServiceImpl(
            FarmRepository farmRepository,
            FarmMapper farmMapper) {
        this.farmRepository = farmRepository;
        this.farmMapper = farmMapper;
    }

    // Create Farm
    @Override
    @Transactional
    public FarmResponseDTO createFarm(FarmRequestDTO requestDTO) {

        Farm farm = farmMapper.toEntity(requestDTO);

        Farm savedFarm = farmRepository.save(farm);

        return farmMapper.toResponseDTO(savedFarm);
    }

    // Get Farm By ID
    @Override
    @Transactional(readOnly = true)
    public FarmResponseDTO getFarmById(Long farmId) {

        Farm farm = farmRepository.findById(farmId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Farm not found with ID: " + farmId));

        return farmMapper.toResponseDTO(farm);
    }

    // Get All Farms
    @Override
    @Transactional(readOnly = true)
    public List<FarmResponseDTO> getAllFarms() {

        return farmRepository.findAll()
                .stream()
                .map(farmMapper::toResponseDTO)
                .toList();
    }

    // Update Farm
    @Override
    @Transactional
    public FarmResponseDTO updateFarm(
            Long farmId,
            FarmUpdateRequestDTO requestDTO) {

        Farm farm = farmRepository.findById(farmId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Farm not found with ID: " + farmId));

        farm.setFarmName(requestDTO.getFarmName());
        farm.setLocation(requestDTO.getLocation());
        farm.setTotalArea(requestDTO.getTotalArea());
        farm.setDescription(requestDTO.getDescription());

        Farm updatedFarm = farmRepository.save(farm);

        return farmMapper.toResponseDTO(updatedFarm);
    }

    // Delete Farm
    @Override
    @Transactional
    public void deleteFarm(Long farmId) {

        Farm farm = farmRepository.findById(farmId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Farm not found with ID: " + farmId));

        farmRepository.delete(farm);
    }
}
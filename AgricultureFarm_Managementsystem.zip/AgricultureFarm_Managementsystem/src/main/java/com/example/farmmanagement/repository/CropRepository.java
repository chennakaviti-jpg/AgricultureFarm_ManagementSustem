package com.example.farmmanagement.repository;

	import org.springframework.data.jpa.repository.JpaRepository;
	import org.springframework.stereotype.Repository;

	import com.example.farmmanagement.entity.Crop;

	@Repository
	public interface CropRepository extends JpaRepository<Crop, Long> {

	}
package com.example.farmmanagement.Controller;

	import java.util.List;

	import org.springframework.http.HttpStatus;
	import org.springframework.http.ResponseEntity;
	import org.springframework.web.bind.annotation.DeleteMapping;
	import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.PathVariable;
	import org.springframework.web.bind.annotation.PostMapping;
	import org.springframework.web.bind.annotation.PutMapping;
	import org.springframework.web.bind.annotation.RequestBody;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.bind.annotation.RestController;

	import com.example.farmmanagement.DTO.request.CropPlanRequestDTO;
	import com.example.farmmanagement.DTO.request.CropPlanUpdateRequestDTO;
	import com.example.farmmanagement.DTO.response.CropPlanResponseDTO;
	import com.example.farmmanagement.service.CropPlanService;

	import jakarta.validation.Valid;

	@RestController
	@RequestMapping("/api/crop-plans")
	public class CropPlanController {

	    private final CropPlanService cropPlanService;

	    public CropPlanController(CropPlanService cropPlanService) {
	        this.cropPlanService = cropPlanService;
	    }

	    // Create a crop plan
	    @PostMapping
	    public ResponseEntity<CropPlanResponseDTO> createCropPlan(
	            @Valid @RequestBody CropPlanRequestDTO requestDTO) {

	        CropPlanResponseDTO response =
	                cropPlanService.createCropPlan(requestDTO);

	        return ResponseEntity.status(HttpStatus.CREATED).body(response);
	    }

	    // Get a crop plan by ID
	    @GetMapping("/{cropPlanId}")
	    public ResponseEntity<CropPlanResponseDTO> getCropPlanById(
	            @PathVariable Long cropPlanId) {

	        CropPlanResponseDTO response =
	                cropPlanService.getCropPlanById(cropPlanId);

	        return ResponseEntity.ok(response);
	    }

	    // Get all crop plans
	    @GetMapping
	    public ResponseEntity<List<CropPlanResponseDTO>> getAllCropPlans() {

	        List<CropPlanResponseDTO> response =
	                cropPlanService.getAllCropPlans();

	        return ResponseEntity.ok(response);
	    }

	    // Update a crop plan
	    @PutMapping("/{cropPlanId}")
	    public ResponseEntity<CropPlanResponseDTO> updateCropPlan(
	            @PathVariable Long cropPlanId,
	            @Valid @RequestBody CropPlanUpdateRequestDTO requestDTO) {

	        CropPlanResponseDTO response =
	                cropPlanService.updateCropPlan(cropPlanId, requestDTO);

	        return ResponseEntity.ok(response);
	    }

	    // Delete a crop plan
	    @DeleteMapping("/{cropPlanId}")
	    public ResponseEntity<Void> deleteCropPlan(
	            @PathVariable Long cropPlanId) {

	        cropPlanService.deleteCropPlan(cropPlanId);

	        return ResponseEntity.noContent().build();
	    }
	}
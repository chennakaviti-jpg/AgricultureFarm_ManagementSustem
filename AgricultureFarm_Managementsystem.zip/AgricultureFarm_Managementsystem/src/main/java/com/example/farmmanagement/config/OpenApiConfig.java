package com.example.farmmanagement.config;

	import io.swagger.v3.oas.models.Components;
	import io.swagger.v3.oas.models.OpenAPI;
	import io.swagger.v3.oas.models.info.Info;
	import io.swagger.v3.oas.models.security.SecurityRequirement;
	import io.swagger.v3.oas.models.security.SecurityScheme;
	import org.springframework.context.annotation.Bean;
	import org.springframework.context.annotation.Configuration;

	@Configuration
	public class OpenApiConfig {

	    @Bean
	    public OpenAPI agricultureFarmOpenAPI() {

	        final String securitySchemeName = "bearerAuth";

	        return new OpenAPI()
	                .info(new Info()
	                        .title("Agriculture Farm Management System API")
	                        .description(
	                                "REST APIs for managing farmers, farms, fields, "
	                                + "crops, resources, activities, monitoring, "
	                                + "harvests, and farm documents.")
	                        .version("1.0.0"))
	                .addSecurityItem(
	                        new SecurityRequirement()
	                                .addList(securitySchemeName))
	                .components(
	                        new Components()
	                                .addSecuritySchemes(
	                                        securitySchemeName,
	                                        new SecurityScheme()
	                                                .name(securitySchemeName)
	                                                .type(SecurityScheme.Type.HTTP)
	                                                .scheme("bearer")
	                                                .bearerFormat("JWT")));
	    }
	}
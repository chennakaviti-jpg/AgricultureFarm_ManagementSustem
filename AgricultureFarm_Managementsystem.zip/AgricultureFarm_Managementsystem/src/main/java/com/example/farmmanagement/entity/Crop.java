package com.example.farmmanagement.entity;

	import jakarta.persistence.*;
	import jakarta.validation.constraints.NotBlank;
	import jakarta.validation.constraints.Positive;

	import java.util.ArrayList;
	import java.util.List;

	@Entity
	@Table(
	    name = "crops",
	    uniqueConstraints = {
	        @UniqueConstraint(
	            name = "uk_crop_name",
	            columnNames = "crop_name"
	        )
	    }
	)
	public class Crop {

	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long cropId;

	    @NotBlank(message = "Crop name is required")
	    @Column(name = "crop_name", nullable = false, length = 100)
	    private String cropName;

	    @NotBlank(message = "Crop category is required")
	    @Column(name = "crop_category", nullable = false, length = 100)
	    private String cropCategory;

	    @Positive(message = "Expected duration must be greater than zero")
	    @Column(name = "expected_duration_days", nullable = false)
	    private Integer expectedDurationDays;

	    @Column(length = 500)
	    private String description;

	    // One Crop can be used in Many Crop Plans
	    @OneToMany(mappedBy = "crop", fetch = FetchType.LAZY)
	    private List<CropPlan> cropPlans = new ArrayList<>();

	    public Crop() {
	    }

	    public Long getCropId() {
	        return cropId;
	    }

	    public void setCropId(Long cropId) {
	        this.cropId = cropId;
	    }

	    public String getCropName() {
	        return cropName;
	    }

	    public void setCropName(String cropName) {
	        this.cropName = cropName;
	    }

	    public String getCropCategory() {
	        return cropCategory;
	    }

	    public void setCropCategory(String cropCategory) {
	        this.cropCategory = cropCategory;
	    }

	    public Integer getExpectedDurationDays() {
	        return expectedDurationDays;
	    }

	    public void setExpectedDurationDays(Integer expectedDurationDays) {
	        this.expectedDurationDays = expectedDurationDays;
	    }

	    public String getDescription() {
	        return description;
	    }

	    public void setDescription(String description) {
	        this.description = description;
	    }

	    public List<CropPlan> getCropPlans() {
	        return cropPlans;
	    }

	    public void setCropPlans(List<CropPlan> cropPlans) {
	        this.cropPlans = cropPlans;
	    }
	}
package com.example.farmmanagement.service;

	import java.util.List;
	import com.example.farmmanagement.DTO.request.ResourceRequestDTO;
	import com.example.farmmanagement.DTO.request.ResourceUpdateRequestDTO;
	import com.example.farmmanagement.DTO.response.ResourceResponseDTO;

	public interface ResourceService {

	    ResourceResponseDTO createResource(ResourceRequestDTO requestDTO);

	    ResourceResponseDTO getResourceById(Long resourceId);

	    List<ResourceResponseDTO> getAllResources();

	    ResourceResponseDTO updateResource(
	            Long resourceId,
	            ResourceUpdateRequestDTO requestDTO);

	    void deleteResource(Long resourceId);
	}
package com.example.farmmanagement.DTO.response;

	public class FarmResponseDTO {

	    private Long farmId;
	    private String farmName;
	    private String location;
	    private Double totalArea;
	    private String description;
	    private Long farmerId;

	    public FarmResponseDTO() {
	    }

	    public Long getFarmId() {
	        return farmId;
	    }

	    public void setFarmId(Long farmId) {
	        this.farmId = farmId;
	    }

	    public String getFarmName() {
	        return farmName;
	    }

	    public void setFarmName(String farmName) {
	        this.farmName = farmName;
	    }

	    public String getLocation() {
	        return location;
	    }

	    public void setLocation(String location) {
	        this.location = location;
	    }

	    public Double getTotalArea() {
	        return totalArea;
	    }

	    public void setTotalArea(Double totalArea) {
	        this.totalArea = totalArea;
	    }

	    public String getDescription() {
	        return description;
	    }

	    public void setDescription(String description) {
	        this.description = description;
	    }

	    public Long getFarmerId() {
	        return farmerId;
	    }

	    public void setFarmerId(Long farmerId) {
	        this.farmerId = farmerId;
	    }
	}
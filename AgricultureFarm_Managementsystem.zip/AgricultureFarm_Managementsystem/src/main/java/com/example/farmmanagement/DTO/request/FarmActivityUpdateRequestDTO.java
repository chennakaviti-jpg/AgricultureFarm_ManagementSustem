package com.example.farmmanagement.DTO.request;

	import java.time.LocalDate;

	import com.example.farmmanagement.enums.ActivityStatus;
	import com.example.farmmanagement.enums.ActivityType;

	import jakarta.validation.constraints.NotNull;
	import jakarta.validation.constraints.Size;

	public class FarmActivityUpdateRequestDTO {

	    @NotNull(message = "Activity type is required")
	    private ActivityType activityType;

	    @Size(max = 500, message = "Description cannot exceed 500 characters")
	    private String description;

	    @NotNull(message = "Scheduled date is required")
	    private LocalDate scheduledDate;

	    private LocalDate completedDate;

	    @NotNull(message = "Activity status is required")
	    private ActivityStatus status;

	    @Size(max = 100, message = "Assigned person cannot exceed 100 characters")
	    private String assignedTo;

	    public FarmActivityUpdateRequestDTO() {
	    }

	    public ActivityType getActivityType() {
	        return activityType;
	    }

	    public void setActivityType(ActivityType activityType) {
	        this.activityType = activityType;
	    }

	    public String getDescription() {
	        return description;
	    }

	    public void setDescription(String description) {
	        this.description = description;
	    }

	    public LocalDate getScheduledDate() {
	        return scheduledDate;
	    }

	    public void setScheduledDate(LocalDate scheduledDate) {
	        this.scheduledDate = scheduledDate;
	    }

	    public LocalDate getCompletedDate() {
	        return completedDate;
	    }

	    public void setCompletedDate(LocalDate completedDate) {
	        this.completedDate = completedDate;
	    }

	    public ActivityStatus getStatus() {
	        return status;
	    }

	    public void setStatus(ActivityStatus status) {
	        this.status = status;
	    }

	    public String getAssignedTo() {
	        return assignedTo;
	    }

	    public void setAssignedTo(String assignedTo) {
	        this.assignedTo = assignedTo;
	    }
	}
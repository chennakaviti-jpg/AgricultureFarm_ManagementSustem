package com.example.farmmanagement.service;

	import java.util.List;

	import com.example.farmmanagement.DTO.request.FarmActivityRequestDTO;
	import com.example.farmmanagement.DTO.request.FarmActivityUpdateRequestDTO;
	import com.example.farmmanagement.DTO.response.FarmActivityResponseDTO;

	public interface FarmActivityService {

	    FarmActivityResponseDTO createActivity(
	            FarmActivityRequestDTO requestDTO);

	    FarmActivityResponseDTO getActivityById(Long activityId);

	    List<FarmActivityResponseDTO> getAllActivities();

	    FarmActivityResponseDTO updateActivity(
	            Long activityId,
	            FarmActivityUpdateRequestDTO requestDTO);

	    void deleteActivity(Long activityId);
	}
package com.example.farmmanagement.service;

	import java.util.List;

	import com.example.farmmanagement.DTO.request.CropPlanRequestDTO;
	import com.example.farmmanagement.DTO.request.CropPlanUpdateRequestDTO;
	import com.example.farmmanagement.DTO.response.CropPlanResponseDTO;

	public interface CropPlanService {

	    CropPlanResponseDTO createCropPlan(
	            CropPlanRequestDTO requestDTO);

	    CropPlanResponseDTO getCropPlanById(Long cropPlanId);

	    List<CropPlanResponseDTO> getAllCropPlans();

	    CropPlanResponseDTO updateCropPlan(
	            Long cropPlanId,
	            CropPlanUpdateRequestDTO requestDTO);

	    void deleteCropPlan(Long cropPlanId);
	}
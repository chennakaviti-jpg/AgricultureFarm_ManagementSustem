package com.example.farmmanagement.repository;

	import org.springframework.data.jpa.repository.JpaRepository;
	import org.springframework.stereotype.Repository;

	import com.example.farmmanagement.entity.CropMonitoring;

	@Repository
	public interface CropMonitoringRepository
	        extends JpaRepository<CropMonitoring, Long> {

	}
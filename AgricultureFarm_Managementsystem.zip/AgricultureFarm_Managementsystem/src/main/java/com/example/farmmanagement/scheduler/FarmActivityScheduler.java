package com.example.farmmanagement.scheduler;

	import java.util.List;

	import org.slf4j.Logger;
	import org.slf4j.LoggerFactory;
	import org.springframework.scheduling.annotation.Scheduled;
	import org.springframework.stereotype.Component;

	import com.example.farmmanagement.DTO.response.FarmActivityResponseDTO;
	import com.example.farmmanagement.service.FarmActivityService;

	@Component
	public class FarmActivityScheduler {

	    private static final Logger logger =
	            LoggerFactory.getLogger(FarmActivityScheduler.class);

	    private final FarmActivityService farmActivityService;

	    public FarmActivityScheduler(
	            FarmActivityService farmActivityService) {
	        this.farmActivityService = farmActivityService;
	    }

	    // Runs every day at 6:00 AM
	    @Scheduled(cron = "0 0 6 * * *")
	    public void checkFarmActivities() {

	        logger.info("Scheduled farm activity check started.");

	        try {
	            List<FarmActivityResponseDTO> activities =
	                    farmActivityService.getAllActivities();

	            logger.info(
	                    "Scheduled farm activity check completed. Total activities: {}",
	                    activities.size());

	        } catch (Exception exception) {
	            logger.error(
	                    "Failed to retrieve farm activities during scheduled check.",
	                    exception);
	        }
	    }
	}
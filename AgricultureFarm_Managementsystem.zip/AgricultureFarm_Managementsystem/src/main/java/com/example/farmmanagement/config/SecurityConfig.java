package com.example.farmmanagement.config;

	import org.springframework.context.annotation.Bean;
	import org.springframework.context.annotation.Configuration;
	import org.springframework.security.config.annotation.web.builders.HttpSecurity;
	import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
	import org.springframework.security.config.http.SessionCreationPolicy;
	import org.springframework.security.web.SecurityFilterChain;
	import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

	import com.example.farmmanagement.security.AuthEntryPoint;
	import com.example.farmmanagement.security.JwtAuthenticationFilter;

	@Configuration
	@EnableWebSecurity
	public class SecurityConfig {

	    private final JwtAuthenticationFilter jwtAuthenticationFilter;
	    private final AuthEntryPoint authEntryPoint;

	    public SecurityConfig(
	            JwtAuthenticationFilter jwtAuthenticationFilter,
	            AuthEntryPoint authEntryPoint) {
	        this.jwtAuthenticationFilter = jwtAuthenticationFilter;
	        this.authEntryPoint = authEntryPoint;
	    }

	    @Bean
	    public SecurityFilterChain securityFilterChain(
	            HttpSecurity http) throws Exception {

	        http
	            .csrf(csrf -> csrf.disable())

	            .sessionManagement(session ->
	                session.sessionCreationPolicy(
	                    SessionCreationPolicy.STATELESS))

	            .exceptionHandling(exception ->
	                exception.authenticationEntryPoint(authEntryPoint))

	            .authorizeHttpRequests(auth -> auth

	                // Public registration and login
	                .requestMatchers(
	                    "/api/auth/register",
	                    "/api/auth/login"
	                ).permitAll()

	                // Public health endpoint
	                .requestMatchers("/actuator/health").permitAll()
	                .requestMatchers("/actuator/metrics").permitAll()
	                .requestMatchers("/actuator/metrics/**").permitAll()


	                // Public Swagger documentation
	                .requestMatchers(
	                    "/swagger-ui.html",
	                    "/swagger-ui/**",
	                    "/v3/api-docs/**"
	                ).permitAll()

	                // Admin-only endpoints
	                .requestMatchers("/api/admin/**")
	                    .hasRole("ADMIN")

	                // Admin and farm manager endpoints
	                .requestMatchers("/api/manager/**")
	                    .hasAnyRole("ADMIN", "FARM_MANAGER")

	                // All other endpoints require authentication
	                .anyRequest().authenticated()
	            )

	            .addFilterBefore(
	                jwtAuthenticationFilter,
	                UsernamePasswordAuthenticationFilter.class)

	            .formLogin(form -> form.disable())
	            .httpBasic(basic -> basic.disable());

	        return http.build();
	    }
	}
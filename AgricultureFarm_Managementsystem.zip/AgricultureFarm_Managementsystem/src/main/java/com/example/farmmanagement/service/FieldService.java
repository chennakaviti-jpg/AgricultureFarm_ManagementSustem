package com.example.farmmanagement.service;

	import java.util.List;

	import com.example.farmmanagement.DTO.request.FieldRequestDTO;
	import com.example.farmmanagement.DTO.request.FieldUpdateRequestDTO;
	import com.example.farmmanagement.DTO.response.FieldResponseDTO;

	public interface FieldService {

	    FieldResponseDTO createField(FieldRequestDTO requestDTO);

	    FieldResponseDTO getFieldById(Long fieldId);

	    List<FieldResponseDTO> getAllFields();

	    FieldResponseDTO updateField(
	            Long fieldId,
	            FieldUpdateRequestDTO requestDTO);

	    void deleteField(Long fieldId);
	}
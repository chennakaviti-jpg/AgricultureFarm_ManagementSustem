package com.example.farmmanagement.Controller;

	import java.util.List;

	import org.springframework.http.HttpStatus;
	import org.springframework.http.ResponseEntity;
	import org.springframework.web.bind.annotation.DeleteMapping;
	import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.PathVariable;
	import org.springframework.web.bind.annotation.PostMapping;
	import org.springframework.web.bind.annotation.PutMapping;
	import org.springframework.web.bind.annotation.RequestBody;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.bind.annotation.RestController;

	import com.example.farmmanagement.DTO.request.HarvestRequestDTO;
	import com.example.farmmanagement.DTO.request.HarvestUpdateRequestDTO;
	import com.example.farmmanagement.DTO.response.HarvestResponseDTO;
	import com.example.farmmanagement.service.HarvestService;

	import jakarta.validation.Valid;

	@RestController
	@RequestMapping("/api/harvests")
	public class HarvestController {

	    private final HarvestService harvestService;

	    public HarvestController(HarvestService harvestService) {
	        this.harvestService = harvestService;
	    }

	    // Record a new harvest
	    @PostMapping
	    public ResponseEntity<HarvestResponseDTO> createHarvest(
	            @Valid @RequestBody HarvestRequestDTO requestDTO) {

	        HarvestResponseDTO response =
	                harvestService.recordHarvest(requestDTO);

	        return ResponseEntity.status(HttpStatus.CREATED).body(response);
	    }

	    // Get a harvest by ID
	    @GetMapping("/{harvestId}")
	    public ResponseEntity<HarvestResponseDTO> getHarvestById(
	            @PathVariable Long harvestId) {

	        HarvestResponseDTO response =
	                harvestService.getHarvestById(harvestId);

	        return ResponseEntity.ok(response);
	    }

	    // Get all harvest records
	    @GetMapping
	    public ResponseEntity<List<HarvestResponseDTO>> getAllHarvests() {

	        List<HarvestResponseDTO> response =
	                harvestService.getAllHarvests();

	        return ResponseEntity.ok(response);
	    }

	    // Update a harvest record
	    @PutMapping("/{harvestId}")
	    public ResponseEntity<HarvestResponseDTO> updateHarvest(
	            @PathVariable Long harvestId,
	            @Valid @RequestBody HarvestUpdateRequestDTO requestDTO) {

	        HarvestResponseDTO response =
	                harvestService.updateHarvest(harvestId, requestDTO);

	        return ResponseEntity.ok(response);
	    }

	    // Delete a harvest record
	    @DeleteMapping("/{harvestId}")
	    public ResponseEntity<Void> deleteHarvest(
	            @PathVariable Long harvestId) {

	        harvestService.deleteHarvest(harvestId);

	        return ResponseEntity.noContent().build();
	    }
	}
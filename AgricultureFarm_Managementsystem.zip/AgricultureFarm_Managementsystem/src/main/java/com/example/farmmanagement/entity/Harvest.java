package com.example.farmmanagement.entity;

	import com.example.farmmanagement.enums.HarvestStatus;
	import com.example.farmmanagement.enums.MeasurementUnit;
	import jakarta.persistence.*;
	import jakarta.validation.constraints.NotNull;
	import jakarta.validation.constraints.Positive;

	import java.time.LocalDate;

	@Entity
	@Table(name = "harvests")
	public class Harvest {

	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long harvestId;

	    @ManyToOne(fetch = FetchType.LAZY, optional = false)
	    @JoinColumn(
	        name = "crop_plan_id",
	        nullable = false,
	        foreignKey = @ForeignKey(name = "fk_harvest_crop_plan")
	    )
	    private CropPlan cropPlan;

	    @NotNull(message = "Harvest date is required")
	    @Column(name = "harvest_date", nullable = false)
	    private LocalDate harvestDate;

	    @NotNull(message = "Quantity is required")
	    @Positive(message = "Harvest quantity must be greater than zero")
	    @Column(nullable = false)
	    private Double quantity;

	    @NotNull(message = "Unit is required")
	    @Enumerated(EnumType.STRING)
	    @Column(nullable = false, length = 30)
	    private MeasurementUnit unit;

	    @Positive(message = "Expected price must be greater than zero")
	    @Column(name = "expected_price")
	    private Double expectedPrice;

	    @Positive(message = "Actual revenue must be greater than zero")
	    @Column(name = "actual_revenue")
	    private Double actualRevenue;

	    @Enumerated(EnumType.STRING)
	    @Column(nullable = false, length = 30)
	    private HarvestStatus status = HarvestStatus.PLANNED;

	    @Column(length = 1000)
	    private String remarks;

	    public Harvest() {
	    }

	    public Long getHarvestId() {
	        return harvestId;
	    }

	    public void setHarvestId(Long harvestId) {
	        this.harvestId = harvestId;
	    }

	    public CropPlan getCropPlan() {
	        return cropPlan;
	    }

	    public void setCropPlan(CropPlan cropPlan) {
	        this.cropPlan = cropPlan;
	    }

	    public LocalDate getHarvestDate() {
	        return harvestDate;
	    }

	    public void setHarvestDate(LocalDate harvestDate) {
	        this.harvestDate = harvestDate;
	    }

	    public Double getQuantity() {
	        return quantity;
	    }

	    public void setQuantity(Double quantity) {
	        this.quantity = quantity;
	    }

	    public MeasurementUnit getUnit() {
	        return unit;
	    }

	    public void setUnit(MeasurementUnit unit) {
	        this.unit = unit;
	    }

	    public Double getExpectedPrice() {
	        return expectedPrice;
	    }

	    public void setExpectedPrice(Double expectedPrice) {
	        this.expectedPrice = expectedPrice;
	    }

	    public Double getActualRevenue() {
	        return actualRevenue;
	    }

	    public void setActualRevenue(Double actualRevenue) {
	        this.actualRevenue = actualRevenue;
	    }

	    public HarvestStatus getStatus() {
	        return status;
	    }

	    public void setStatus(HarvestStatus status) {
	        this.status = status;
	    }

	    public String getRemarks() {
	        return remarks;
	    }

	    public void setRemarks(String remarks) {
	        this.remarks = remarks;
	    }
	}
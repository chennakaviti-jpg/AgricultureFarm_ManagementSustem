package com.example.farmmanagement.entity;

	import com.example.farmmanagement.enums.ActivityStatus;
	import com.example.farmmanagement.enums.ActivityType;
	import jakarta.persistence.*;
	import jakarta.validation.constraints.NotBlank;
	import jakarta.validation.constraints.NotNull;

	import java.time.LocalDate;
	import java.util.ArrayList;
	import java.util.List;

	@Entity
	@Table(name = "farm_activities")
	public class FarmActivity {

	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long activityId;

	    @ManyToOne(fetch = FetchType.LAZY, optional = false)
	    @JoinColumn(
	        name = "crop_plan_id",
	        nullable = false,
	        foreignKey = @ForeignKey(name = "fk_activity_crop_plan")
	    )
	    private CropPlan cropPlan;

	    @Enumerated(EnumType.STRING)
	    @Column(name = "activity_type", nullable = false, length = 50)
	    private ActivityType activityType;

	    @NotBlank(message = "Activity description is required")
	    @Column(nullable = false, length = 500)
	    private String description;

	    @NotNull(message = "Scheduled date is required")
	    @Column(name = "scheduled_date", nullable = false)
	    private LocalDate scheduledDate;

	    @Column(name = "completed_date")
	    private LocalDate completedDate;

	    @Enumerated(EnumType.STRING)
	    @Column(nullable = false, length = 30)
	    private ActivityStatus status = ActivityStatus.PLANNED;

	    @Column(length = 100)
	    private String assignedTo;

	    // One FarmActivity can have Many ResourceUsage records
	    @OneToMany(mappedBy = "activity", fetch = FetchType.LAZY)
	    private List<ResourceUsage> resourceUsages = new ArrayList<>();

	    public FarmActivity() {
	    }

	    public Long getActivityId() {
	        return activityId;
	    }

	    public void setActivityId(Long activityId) {
	        this.activityId = activityId;
	    }

	    public CropPlan getCropPlan() {
	        return cropPlan;
	    }

	    public void setCropPlan(CropPlan cropPlan) {
	        this.cropPlan = cropPlan;
	    }

	    public ActivityType getActivityType() {
	        return activityType;
	    }

	    public void setActivityType(ActivityType activityType) {
	        this.activityType = activityType;
	    }

	    public String getDescription() {
	        return description;
	    }

	    public void setDescription(String description) {
	        this.description = description;
	    }

	    public LocalDate getScheduledDate() {
	        return scheduledDate;
	    }

	    public void setScheduledDate(LocalDate scheduledDate) {
	        this.scheduledDate = scheduledDate;
	    }

	    public LocalDate getCompletedDate() {
	        return completedDate;
	    }

	    public void setCompletedDate(LocalDate completedDate) {
	        this.completedDate = completedDate;
	    }

	    public ActivityStatus getStatus() {
	        return status;
	    }

	    public void setStatus(ActivityStatus status) {
	        this.status = status;
	    }

	    public String getAssignedTo() {
	        return assignedTo;
	    }

	    public void setAssignedTo(String assignedTo) {
	        this.assignedTo = assignedTo;
	    }

	    public List<ResourceUsage> getResourceUsages() {
	        return resourceUsages;
	    }

	    public void setResourceUsages(List<ResourceUsage> resourceUsages) {
	        this.resourceUsages = resourceUsages;
	    }
	}
package com.example.farmmanagement.DTO.response;

	import java.time.LocalDateTime;

	import com.example.farmmanagement.enums.DocumentType;

	public class FarmDocumentResponseDTO {

	    private Long documentId;
	    private Long farmId;
	    private String originalFileName;
	    private String fileType;
	    private DocumentType documentType;
	    private Long fileSize;
	    private LocalDateTime uploadedAt;
	    private String description;

	    public FarmDocumentResponseDTO() {
	    }

	    public Long getDocumentId() {
	        return documentId;
	    }

	    public void setDocumentId(Long documentId) {
	        this.documentId = documentId;
	    }

	    public Long getFarmId() {
	        return farmId;
	    }

	    public void setFarmId(Long farmId) {
	        this.farmId = farmId;
	    }

	    public String getOriginalFileName() {
	        return originalFileName;
	    }

	    public void setOriginalFileName(String originalFileName) {
	        this.originalFileName = originalFileName;
	    }

	    public String getFileType() {
	        return fileType;
	    }

	    public void setFileType(String fileType) {
	        this.fileType = fileType;
	    }

	    public DocumentType getDocumentType() {
	        return documentType;
	    }

	    public void setDocumentType(DocumentType documentType) {
	        this.documentType = documentType;
	    }

	    public Long getFileSize() {
	        return fileSize;
	    }

	    public void setFileSize(Long fileSize) {
	        this.fileSize = fileSize;
	    }

	    public LocalDateTime getUploadedAt() {
	        return uploadedAt;
	    }

	    public void setUploadedAt(LocalDateTime uploadedAt) {
	        this.uploadedAt = uploadedAt;
	    }

	    public String getDescription() {
	        return description;
	    }

	    public void setDescription(String description) {
	        this.description = description;
	    }
	}
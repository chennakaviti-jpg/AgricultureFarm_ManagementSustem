package com.example.farmmanagement.DTO.request;

	import java.time.LocalDate;

	import com.example.farmmanagement.enums.HarvestStatus;
	import com.example.farmmanagement.enums.MeasurementUnit;

	import jakarta.validation.constraints.DecimalMin;
	import jakarta.validation.constraints.NotNull;
	import jakarta.validation.constraints.Size;

	public class HarvestUpdateRequestDTO {

	    @NotNull(message = "Harvest date is required")
	    private LocalDate harvestDate;

	    @NotNull(message = "Harvest quantity is required")
	    @DecimalMin(value = "0.0",
	            message = "Harvest quantity cannot be negative")
	    private Double quantity;

	    @NotNull(message = "Measurement unit is required")
	    private MeasurementUnit unit;

	    @NotNull(message = "Expected price is required")
	    @DecimalMin(value = "0.0",
	            message = "Expected price cannot be negative")
	    private Double expectedPrice;

	    @DecimalMin(value = "0.0",
	            message = "Actual revenue cannot be negative")
	    private Double actualRevenue;

	    @NotNull(message = "Harvest status is required")
	    private HarvestStatus status;

	    @Size(max = 1000, message = "Remarks cannot exceed 1000 characters")
	    private String remarks;

	    public HarvestUpdateRequestDTO() {
	    }

	    public LocalDate getHarvestDate() {
	        return harvestDate;
	    }

	    public void setHarvestDate(LocalDate harvestDate) {
	        this.harvestDate = harvestDate;
	    }

	    public Double getQuantity() {
	        return quantity;
	    }

	    public void setQuantity(Double quantity) {
	        this.quantity = quantity;
	    }

	    public MeasurementUnit getUnit() {
	        return unit;
	    }

	    public void setUnit(MeasurementUnit unit) {
	        this.unit = unit;
	    }

	    public Double getExpectedPrice() {
	        return expectedPrice;
	    }

	    public void setExpectedPrice(Double expectedPrice) {
	        this.expectedPrice = expectedPrice;
	    }

	    public Double getActualRevenue() {
	        return actualRevenue;
	    }

	    public void setActualRevenue(Double actualRevenue) {
	        this.actualRevenue = actualRevenue;
	    }

	    public HarvestStatus getStatus() {
	        return status;
	    }

	    public void setStatus(HarvestStatus status) {
	        this.status = status;
	    }

	    public String getRemarks() {
	        return remarks;
	    }

	    public void setRemarks(String remarks) {
	        this.remarks = remarks;
	    }
	}
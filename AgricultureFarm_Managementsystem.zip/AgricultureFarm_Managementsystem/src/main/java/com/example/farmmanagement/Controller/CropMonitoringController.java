package com.example.farmmanagement.Controller;

	import java.util.List;

	import org.springframework.http.HttpStatus;
	import org.springframework.http.ResponseEntity;
	import org.springframework.web.bind.annotation.DeleteMapping;
	import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.PathVariable;
	import org.springframework.web.bind.annotation.PostMapping;
	import org.springframework.web.bind.annotation.PutMapping;
	import org.springframework.web.bind.annotation.RequestBody;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.bind.annotation.RestController;

	import com.example.farmmanagement.DTO.request.CropMonitoringRequestDTO;
	import com.example.farmmanagement.DTO.request.CropMonitoringUpdateRequestDTO;
	import com.example.farmmanagement.DTO.response.CropMonitoringResponseDTO;
	import com.example.farmmanagement.service.CropMonitoringService;

	import jakarta.validation.Valid;

	@RestController
	@RequestMapping("/api/crop-monitorings")
	public class CropMonitoringController {

	    private final CropMonitoringService cropMonitoringService;

	    public CropMonitoringController(
	            CropMonitoringService cropMonitoringService) {
	        this.cropMonitoringService = cropMonitoringService;
	    }

	    // Create a crop monitoring record
	    @PostMapping
	    public ResponseEntity<CropMonitoringResponseDTO> createCropMonitoring(
	            @Valid @RequestBody CropMonitoringRequestDTO requestDTO) {

	        CropMonitoringResponseDTO response =
	                cropMonitoringService.recordMonitoring(requestDTO);

	        return ResponseEntity.status(HttpStatus.CREATED).body(response);
	    }

	    // Get a crop monitoring record by ID
	    @GetMapping("/{monitoringId}")
	    public ResponseEntity<CropMonitoringResponseDTO> getCropMonitoringById(
	            @PathVariable Long monitoringId) {

	        CropMonitoringResponseDTO response =
	                cropMonitoringService.getMonitoringById(monitoringId);

	        return ResponseEntity.ok(response);
	    }

	    // Get all crop monitoring records
	    @GetMapping
	    public ResponseEntity<List<CropMonitoringResponseDTO>> getAllCropMonitorings() {

	        List<CropMonitoringResponseDTO> response =
	                cropMonitoringService.getAllMonitoringRecords();

	        return ResponseEntity.ok(response);
	    }

	    // Update a crop monitoring record
	    @PutMapping("/{monitoringId}")
	    public ResponseEntity<CropMonitoringResponseDTO> updateCropMonitoring(
	            @PathVariable Long monitoringId,
	            @Valid @RequestBody CropMonitoringUpdateRequestDTO requestDTO) {

	        CropMonitoringResponseDTO response =
	                cropMonitoringService.updateMonitoring(
	                        monitoringId, requestDTO);

	        return ResponseEntity.ok(response);
	    }

	    // Delete a crop monitoring record
	    @DeleteMapping("/{monitoringId}")
	    public ResponseEntity<Void> deleteCropMonitoring(
	            @PathVariable Long monitoringId) {

	        cropMonitoringService.deleteMonitoring(monitoringId);

	        return ResponseEntity.noContent().build();
	    }
	}
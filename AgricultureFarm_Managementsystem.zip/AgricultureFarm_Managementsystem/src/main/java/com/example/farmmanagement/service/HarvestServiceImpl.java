package com.example.farmmanagement.service;

	import java.util.List;

	import org.springframework.stereotype.Service;
	import org.springframework.transaction.annotation.Transactional;

	import com.example.farmmanagement.DTO.request.HarvestRequestDTO;
	import com.example.farmmanagement.DTO.request.HarvestUpdateRequestDTO;
	import com.example.farmmanagement.DTO.response.HarvestResponseDTO;
	import com.example.farmmanagement.entity.Harvest;
	import com.example.farmmanagement.exception.ResourceNotFoundException;
	import com.example.farmmanagement.mapper.HarvestMapper;
	import com.example.farmmanagement.repository.HarvestRepository;

	@Service
	@Transactional
	public class HarvestServiceImpl implements HarvestService {

	    private final HarvestRepository harvestRepository;
	    private final HarvestMapper harvestMapper;

	    public HarvestServiceImpl(
	            HarvestRepository harvestRepository,
	            HarvestMapper harvestMapper) {
	        this.harvestRepository = harvestRepository;
	        this.harvestMapper = harvestMapper;
	    }

	    // Record Harvest
	    @Override
	    public HarvestResponseDTO recordHarvest(HarvestRequestDTO requestDTO) {

	        Harvest harvest = harvestMapper.toEntity(requestDTO);
	        Harvest savedHarvest = harvestRepository.save(harvest);

	        return harvestMapper.toResponseDTO(savedHarvest);
	    }

	    // Get Harvest By ID
	    @Override
	    @Transactional(readOnly = true)
	    public HarvestResponseDTO getHarvestById(Long harvestId) {

	        Harvest harvest = harvestRepository.findById(harvestId)
	                .orElseThrow(() -> new ResourceNotFoundException(
	                        "Harvest record not found with ID: " + harvestId));

	        return harvestMapper.toResponseDTO(harvest);
	    }

	    // Get All Harvests
	    @Override
	    @Transactional(readOnly = true)
	    public List<HarvestResponseDTO> getAllHarvests() {

	        return harvestRepository.findAll()
	                .stream()
	                .map(harvestMapper::toResponseDTO)
	                .toList();
	    }

	    // Update Harvest
	    @Override
	    public HarvestResponseDTO updateHarvest(
	            Long harvestId,
	            HarvestUpdateRequestDTO requestDTO) {

	        Harvest harvest = harvestRepository.findById(harvestId)
	                .orElseThrow(() -> new ResourceNotFoundException(
	                        "Harvest record not found with ID: " + harvestId));

	        harvest.setHarvestDate(requestDTO.getHarvestDate());
	        harvest.setQuantity(requestDTO.getQuantity());
	        harvest.setUnit(requestDTO.getUnit());
	        harvest.setExpectedPrice(requestDTO.getExpectedPrice());
	        harvest.setActualRevenue(requestDTO.getActualRevenue());
	        harvest.setStatus(requestDTO.getStatus());
	        harvest.setRemarks(requestDTO.getRemarks());

	        Harvest updatedHarvest = harvestRepository.save(harvest);

	        return harvestMapper.toResponseDTO(updatedHarvest);
	    }

	    // Delete Harvest
	    @Override
	    public void deleteHarvest(Long harvestId) {

	        Harvest harvest = harvestRepository.findById(harvestId)
	                .orElseThrow(() -> new ResourceNotFoundException(
	                        "Harvest record not found with ID: " + harvestId));

	        harvestRepository.delete(harvest);
	    }
	}
package com.example.farmmanagement.DTO.response;

	public class FieldResponseDTO {

	    private Long fieldId;
	    private String fieldName;
	    private Double area;
	    private String soilType;
	    private String description;
	    private Long farmId;

	    public FieldResponseDTO() {
	    }

	    public Long getFieldId() {
	        return fieldId;
	    }

	    public void setFieldId(Long fieldId) {
	        this.fieldId = fieldId;
	    }

	    public String getFieldName() {
	        return fieldName;
	    }

	    public void setFieldName(String fieldName) {
	        this.fieldName = fieldName;
	    }

	    public Double getArea() {
	        return area;
	    }

	    public void setArea(Double area) {
	        this.area = area;
	    }

	    public String getSoilType() {
	        return soilType;
	    }

	    public void setSoilType(String soilType) {
	        this.soilType = soilType;
	    }

	    public String getDescription() {
	        return description;
	    }

	    public void setDescription(String description) {
	        this.description = description;
	    }

	    public Long getFarmId() {
	        return farmId;
	    }

	    public void setFarmId(Long farmId) {
	        this.farmId = farmId;
	    }
	}
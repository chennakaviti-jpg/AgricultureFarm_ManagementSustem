package com.example.farmmanagement.enums;

public enum ResourceType {

	    SEED,
	    FERTILIZER,
	    PESTICIDE,
	    HERBICIDE,
	    WATER,
	    FUEL,
	    ELECTRICITY,
	    FARM_EQUIPMENT,
	    LABOUR
	}
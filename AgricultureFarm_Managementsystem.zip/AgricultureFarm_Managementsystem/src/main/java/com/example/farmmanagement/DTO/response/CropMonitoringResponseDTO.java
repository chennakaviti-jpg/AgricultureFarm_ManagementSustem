package com.example.farmmanagement.DTO.response;

	import java.time.LocalDate;

	public class CropMonitoringResponseDTO {

	    private Long monitoringId;
	    private Long cropPlanId;
	    private LocalDate monitoringDate;
	    private String growthStage;
	    private String healthStatus;
	    private Boolean pestDetected;
	    private Boolean diseaseDetected;
	    private String observations;

	    public CropMonitoringResponseDTO() {
	    }

	    public Long getMonitoringId() {
	        return monitoringId;
	    }

	    public void setMonitoringId(Long monitoringId) {
	        this.monitoringId = monitoringId;
	    }

	    public Long getCropPlanId() {
	        return cropPlanId;
	    }

	    public void setCropPlanId(Long cropPlanId) {
	        this.cropPlanId = cropPlanId;
	    }

	    public LocalDate getMonitoringDate() {
	        return monitoringDate;
	    }

	    public void setMonitoringDate(LocalDate monitoringDate) {
	        this.monitoringDate = monitoringDate;
	    }

	    public String getGrowthStage() {
	        return growthStage;
	    }

	    public void setGrowthStage(String growthStage) {
	        this.growthStage = growthStage;
	    }

	    public String getHealthStatus() {
	        return healthStatus;
	    }

	    public void setHealthStatus(String healthStatus) {
	        this.healthStatus = healthStatus;
	    }

	    public Boolean getPestDetected() {
	        return pestDetected;
	    }

	    public void setPestDetected(Boolean pestDetected) {
	        this.pestDetected = pestDetected;
	    }

	    public Boolean getDiseaseDetected() {
	        return diseaseDetected;
	    }

	    public void setDiseaseDetected(Boolean diseaseDetected) {
	        this.diseaseDetected = diseaseDetected;
	    }

	    public String getObservations() {
	        return observations;
	    }

	    public void setObservations(String observations) {
	        this.observations = observations;
	    }
	}
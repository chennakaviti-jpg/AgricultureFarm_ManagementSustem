package com.example.farmmanagement.entity;

	import com.example.farmmanagement.enums.MeasurementUnit;
	import jakarta.persistence.*;
	import jakarta.validation.constraints.NotNull;
	import jakarta.validation.constraints.Positive;

	@Entity
	@Table(name = "resource_usage")
	public class ResourceUsage {

	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long usageId;

	    @ManyToOne(fetch = FetchType.LAZY, optional = false)
	    @JoinColumn(
	        name = "activity_id",
	        nullable = false,
	        foreignKey = @ForeignKey(name = "fk_usage_activity")
	    )
	    private FarmActivity activity;

	    @ManyToOne(fetch = FetchType.LAZY, optional = false)
	    @JoinColumn(
	        name = "resource_id",
	        nullable = false,
	        foreignKey = @ForeignKey(name = "fk_usage_resource")
	    )
	    private Resource resource;

	    @NotNull(message = "Used quantity is required")
	    @Positive(message = "Used quantity must be greater than zero")
	    @Column(name = "used_quantity", nullable = false)
	    private Double usedQuantity;

	    @NotNull(message = "Unit is required")
	    @Enumerated(EnumType.STRING)
	    @Column(nullable = false, length = 30)
	    private MeasurementUnit unit;

	    @Column(length = 500)
	    private String remarks;

	    public ResourceUsage() {
	    }

	    public Long getUsageId() {
	        return usageId;
	    }

	    public void setUsageId(Long usageId) {
	        this.usageId = usageId;
	    }

	    public FarmActivity getActivity() {
	        return activity;
	    }

	    public void setActivity(FarmActivity activity) {
	        this.activity = activity;
	    }

	    public Resource getResource() {
	        return resource;
	    }

	    public void setResource(Resource resource) {
	        this.resource = resource;
	    }

	    public Double getUsedQuantity() {
	        return usedQuantity;
	    }

	    public void setUsedQuantity(Double usedQuantity) {
	        this.usedQuantity = usedQuantity;
	    }

	    public MeasurementUnit getUnit() {
	        return unit;
	    }

	    public void setUnit(MeasurementUnit unit) {
	        this.unit = unit;
	    }

	    public String getRemarks() {
	        return remarks;
	    }

	    public void setRemarks(String remarks) {
	        this.remarks = remarks;
	    }
	}
package com.example.farmmanagement.repository;

	import org.springframework.data.jpa.repository.JpaRepository;
	import org.springframework.stereotype.Repository;

	import com.example.farmmanagement.entity.CropPlan;

	@Repository
	public interface CropPlanRepository extends JpaRepository<CropPlan, Long> {

	}
package com.example.farmmanagement.controller;

	import static org.mockito.Mockito.verify;
	import static org.mockito.Mockito.when;
	import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
	import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

	import java.util.List;

	import org.junit.jupiter.api.BeforeEach;
	import org.junit.jupiter.api.Test;
	import org.junit.jupiter.api.extension.ExtendWith;
	import org.springframework.http.MediaType;
	import org.springframework.test.web.servlet.MockMvc;
	import org.springframework.test.web.servlet.setup.MockMvcBuilders;

	import com.example.farmmanagement.Controller.FarmController;
	import com.example.farmmanagement.DTO.request.FarmRequestDTO;
	import com.example.farmmanagement.DTO.request.FarmUpdateRequestDTO;
	import com.example.farmmanagement.DTO.response.FarmResponseDTO;
	import com.example.farmmanagement.exception.GlobalExceptionHandler;
	import com.example.farmmanagement.exception.ResourceNotFoundException;
	import com.example.farmmanagement.service.FarmService;
	import com.fasterxml.jackson.databind.ObjectMapper;

	import org.mockito.InjectMocks;
	import org.mockito.Mock;
	import org.mockito.junit.jupiter.MockitoExtension;

	@ExtendWith(MockitoExtension.class)
	class FarmControllerTest {

	    @Mock
	    private FarmService farmService;

	    @InjectMocks
	    private FarmController farmController;

	    private MockMvc mockMvc;

	    private ObjectMapper objectMapper;

	    @BeforeEach
	    void setUp() {
	        mockMvc = MockMvcBuilders
	                .standaloneSetup(farmController)
	                .setControllerAdvice(new GlobalExceptionHandler())
	                .build();

	        objectMapper = new ObjectMapper();
	    }

	    @Test
	    void getFarmById_shouldReturn200_whenFarmExists() throws Exception {
	        FarmResponseDTO response = new FarmResponseDTO();

	        when(farmService.getFarmById(5L)).thenReturn(response);

	        mockMvc.perform(get("/api/farms/5"))
	                .andExpect(status().isOk());

	        verify(farmService).getFarmById(5L);
	    }

	    @Test
	    void getFarmById_shouldReturn404_whenFarmDoesNotExist() throws Exception {
	        when(farmService.getFarmById(999L))
	                .thenThrow(new ResourceNotFoundException(
	                        "Farm not found with ID: 999"));

	        mockMvc.perform(get("/api/farms/999"))
	                .andExpect(status().isNotFound());

	        verify(farmService).getFarmById(999L);
	    }

	    @Test
	    void getAllFarms_shouldReturn200() throws Exception {
	        when(farmService.getAllFarms())
	                .thenReturn(List.of(new FarmResponseDTO()));

	        mockMvc.perform(get("/api/farms"))
	                .andExpect(status().isOk());

	        verify(farmService).getAllFarms();
	    }

	    @Test
	    void createFarm_shouldReturn201() throws Exception {
	        FarmRequestDTO request = new FarmRequestDTO();
	        request.setFarmName("Green Valley Farm");
	        request.setLocation("Hyderabad, Telangana");
	        request.setTotalArea(10.5);
	        request.setFarmerId(1L);
	        request.setDescription("Controller test farm");

	        when(farmService.createFarm(
	                org.mockito.ArgumentMatchers.any(FarmRequestDTO.class)))
	                .thenReturn(new FarmResponseDTO());

	        mockMvc.perform(post("/api/farms")
	                .contentType(MediaType.APPLICATION_JSON)
	                .content(objectMapper.writeValueAsString(request)))
	                .andExpect(status().isCreated());

	        verify(farmService)
	                .createFarm(org.mockito.ArgumentMatchers.any(FarmRequestDTO.class));
	    }

	    @Test
	    void updateFarm_shouldReturn200() throws Exception {
	        FarmUpdateRequestDTO request = new FarmUpdateRequestDTO();
	        request.setFarmName("Updated Green Valley Farm");
	        request.setLocation("Warangal, Telangana");
	        request.setTotalArea(12.5);
	        request.setDescription("Updated controller test farm");

	        when(farmService.updateFarm(
	                org.mockito.ArgumentMatchers.eq(5L),
	                org.mockito.ArgumentMatchers.any(FarmUpdateRequestDTO.class)))
	                .thenReturn(new FarmResponseDTO());

	        mockMvc.perform(put("/api/farms/5")
	                .contentType(MediaType.APPLICATION_JSON)
	                .content(objectMapper.writeValueAsString(request)))
	                .andExpect(status().isOk());

	        verify(farmService).updateFarm(
	                org.mockito.ArgumentMatchers.eq(5L),
	                org.mockito.ArgumentMatchers.any(FarmUpdateRequestDTO.class));
	    }

	    @Test
	    void deleteFarm_shouldReturn204() throws Exception {
	        mockMvc.perform(delete("/api/farms/5"))
	                .andExpect(status().isNoContent());

	        verify(farmService).deleteFarm(5L);
	    }
	}
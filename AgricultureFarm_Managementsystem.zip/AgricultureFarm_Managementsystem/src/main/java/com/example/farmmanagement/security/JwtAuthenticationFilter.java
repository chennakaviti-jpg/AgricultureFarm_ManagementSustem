package com.example.farmmanagement.security;

import java.io.IOException;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private final JwtService jwtService;
    private final CustomUserDetailsService userDetailsService;

    public JwtAuthenticationFilter(
            JwtService jwtService,
            CustomUserDetailsService userDetailsService) {

        this.jwtService = jwtService;
        this.userDetailsService = userDetailsService;
    }

    @Override
    protected void doFilterInternal(
            HttpServletRequest request,
            HttpServletResponse response,
            FilterChain filterChain)
            throws ServletException, IOException {

        String authorizationHeader =
                request.getHeader("Authorization");

        // Diagnostic messages: never print the actual JWT token
        System.out.println("===== JWT AUTHENTICATION DEBUG =====");
        System.out.println("Request URI: " + request.getRequestURI());

        System.out.println("Authorization header present: "
                + (authorizationHeader != null));

        System.out.println("Bearer token received: "
                + (authorizationHeader != null
                && authorizationHeader.startsWith("Bearer ")));

        if (authorizationHeader == null
                || !authorizationHeader.startsWith("Bearer ")) {

            System.out.println(
                    "JWT authentication skipped: Bearer token missing.");

            filterChain.doFilter(request, response);
            return;
        }

        String token = authorizationHeader.substring(7);

        try {
            String username = jwtService.extractUsername(token);

            System.out.println("JWT username extracted: "
                    + (username != null && !username.isBlank()));

            if (username != null
                    && SecurityContextHolder.getContext()
                            .getAuthentication() == null) {

                UserDetails userDetails =
                        userDetailsService.loadUserByUsername(username);

                boolean tokenValid = jwtService.isTokenValid(
                        token, userDetails.getUsername());

                System.out.println("JWT token valid: " + tokenValid);
                System.out.println("User account enabled: "
                        + userDetails.isEnabled());

                if (tokenValid && userDetails.isEnabled()) {

                    UsernamePasswordAuthenticationToken authentication =
                            new UsernamePasswordAuthenticationToken(
                                    userDetails,
                                    null,
                                    userDetails.getAuthorities());

                    authentication.setDetails(
                            new WebAuthenticationDetailsSource()
                                    .buildDetails(request));

                    SecurityContextHolder.getContext()
                            .setAuthentication(authentication);

                    System.out.println(
                            "JWT authentication successful.");
                } else {
                    System.out.println(
                            "JWT authentication failed: token invalid "
                                    + "or account disabled.");
                }
            }

        } catch (io.jsonwebtoken.JwtException
                | IllegalArgumentException exception) {

            SecurityContextHolder.clearContext();

            System.out.println("JWT authentication failed: "
                    + exception.getClass().getSimpleName());
        }

        System.out.println("====================================");

        filterChain.doFilter(request, response);
    }
}
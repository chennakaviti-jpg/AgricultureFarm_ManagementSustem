package com.example.farmmanagement.DTO.request;

	import com.example.farmmanagement.enums.DocumentType;

	import jakarta.validation.constraints.NotNull;
	import jakarta.validation.constraints.Size;

	public class FarmDocumentUpdateRequestDTO {

	    @NotNull(message = "Document type is required")
	    private DocumentType documentType;

	    @Size(max = 500, message = "Description cannot exceed 500 characters")
	    private String description;

	    public FarmDocumentUpdateRequestDTO() {
	    }

	    public DocumentType getDocumentType() {
	        return documentType;
	    }

	    public void setDocumentType(DocumentType documentType) {
	        this.documentType = documentType;
	    }

	    public String getDescription() {
	        return description;
	    }

	    public void setDescription(String description) {
	        this.description = description;
	    }
	}
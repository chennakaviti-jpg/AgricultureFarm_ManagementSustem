package com.example.farmmanagement.service;

	import java.util.List;

	import com.example.farmmanagement.DTO.request.FarmerRequestDTO;
	import com.example.farmmanagement.DTO.request.FarmerUpdateRequestDTO;
	import com.example.farmmanagement.DTO.response.FarmerResponseDTO;

	public interface FarmerService {

	    FarmerResponseDTO createFarmer(FarmerRequestDTO requestDTO);

	    FarmerResponseDTO getFarmerById(Long farmerId);

	    List<FarmerResponseDTO> getAllFarmers();

	    FarmerResponseDTO updateFarmer(
	            Long farmerId,
	            FarmerUpdateRequestDTO requestDTO);

	    void deleteFarmer(Long farmerId);
	}
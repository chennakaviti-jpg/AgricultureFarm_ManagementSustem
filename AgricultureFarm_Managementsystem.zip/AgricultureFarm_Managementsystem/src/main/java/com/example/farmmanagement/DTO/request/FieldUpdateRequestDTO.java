package com.example.farmmanagement.DTO.request;

	import jakarta.validation.constraints.DecimalMin;
	import jakarta.validation.constraints.NotBlank;
	import jakarta.validation.constraints.NotNull;
	import jakarta.validation.constraints.Size;

	public class FieldUpdateRequestDTO {

	    @NotBlank(message = "Field name is required")
	    @Size(max = 100, message = "Field name cannot exceed 100 characters")
	    private String fieldName;

	    @NotNull(message = "Field area is required")
	    @DecimalMin(value = "0.0", inclusive = false,
	            message = "Field area must be greater than zero")
	    private Double area;

	    @NotBlank(message = "Soil type is required")
	    @Size(max = 100, message = "Soil type cannot exceed 100 characters")
	    private String soilType;

	    private String description;

	    public FieldUpdateRequestDTO() {
	    }

	    public String getFieldName() {
	        return fieldName;
	    }

	    public void setFieldName(String fieldName) {
	        this.fieldName = fieldName;
	    }

	    public Double getArea() {
	        return area;
	    }

	    public void setArea(Double area) {
	        this.area = area;
	    }

	    public String getSoilType() {
	        return soilType;
	    }

	    public void setSoilType(String soilType) {
	        this.soilType = soilType;
	    }

	    public String getDescription() {
	        return description;
	    }

	    public void setDescription(String description) {
	        this.description = description;
	    }
	}
package com.example.farmmanagement.repository;

	import org.springframework.data.jpa.repository.JpaRepository;
	import org.springframework.stereotype.Repository;

	import com.example.farmmanagement.entity.ResourceUsage;

	@Repository
	public interface ResourceUsageRepository
	        extends JpaRepository<ResourceUsage, Long> {

	}
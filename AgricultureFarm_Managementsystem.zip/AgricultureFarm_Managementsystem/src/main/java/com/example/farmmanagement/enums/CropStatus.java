package com.example.farmmanagement.enums;

public enum CropStatus {
	    PLANNED,
	    SOWN,
	    GROWING,
	    FLOWERING,
	    READY_FOR_HARVEST,
	    HARVESTED
	}
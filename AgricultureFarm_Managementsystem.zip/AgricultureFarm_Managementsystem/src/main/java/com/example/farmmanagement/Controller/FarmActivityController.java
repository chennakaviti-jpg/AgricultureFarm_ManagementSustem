package com.example.farmmanagement.Controller;

	import java.util.List;

	import org.springframework.http.HttpStatus;
	import org.springframework.http.ResponseEntity;
	import org.springframework.web.bind.annotation.DeleteMapping;
	import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.PathVariable;
	import org.springframework.web.bind.annotation.PostMapping;
	import org.springframework.web.bind.annotation.PutMapping;
	import org.springframework.web.bind.annotation.RequestBody;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.bind.annotation.RestController;

	import com.example.farmmanagement.DTO.request.FarmActivityRequestDTO;
	import com.example.farmmanagement.DTO.request.FarmActivityUpdateRequestDTO;
	import com.example.farmmanagement.DTO.response.FarmActivityResponseDTO;
	import com.example.farmmanagement.service.FarmActivityService;

	import jakarta.validation.Valid;

	@RestController
	@RequestMapping("/api/farm-activities")
	public class FarmActivityController {

	    private final FarmActivityService farmActivityService;

	    public FarmActivityController(FarmActivityService farmActivityService) {
	        this.farmActivityService = farmActivityService;
	    }

	    // Create a new farm activity
	    @PostMapping
	    public ResponseEntity<FarmActivityResponseDTO> createActivity(
	            @Valid @RequestBody FarmActivityRequestDTO requestDTO) {

	        FarmActivityResponseDTO response =
	                farmActivityService.createActivity(requestDTO);

	        return ResponseEntity.status(HttpStatus.CREATED).body(response);
	    }

	    // Get a farm activity by ID
	    @GetMapping("/{activityId}")
	    public ResponseEntity<FarmActivityResponseDTO> getActivityById(
	            @PathVariable Long activityId) {

	        FarmActivityResponseDTO response =
	                farmActivityService.getActivityById(activityId);

	        return ResponseEntity.ok(response);
	    }

	    // Get all farm activities
	    @GetMapping
	    public ResponseEntity<List<FarmActivityResponseDTO>> getAllActivities() {

	        List<FarmActivityResponseDTO> response =
	                farmActivityService.getAllActivities();

	        return ResponseEntity.ok(response);
	    }

	    // Update a farm activity
	    @PutMapping("/{activityId}")
	    public ResponseEntity<FarmActivityResponseDTO> updateActivity(
	            @PathVariable Long activityId,
	            @Valid @RequestBody FarmActivityUpdateRequestDTO requestDTO) {

	        FarmActivityResponseDTO response =
	                farmActivityService.updateActivity(activityId, requestDTO);

	        return ResponseEntity.ok(response);
	    }

	    // Delete a farm activity
	    @DeleteMapping("/{activityId}")
	    public ResponseEntity<Void> deleteActivity(
	            @PathVariable Long activityId) {

	        farmActivityService.deleteActivity(activityId);

	        return ResponseEntity.noContent().build();
	    }
	}
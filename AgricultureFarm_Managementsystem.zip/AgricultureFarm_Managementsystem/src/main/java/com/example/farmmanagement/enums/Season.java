package com.example.farmmanagement.enums;

public enum Season {
       KHARIF,
       RABI,
       ZAID
}

package com.example.farmmanagement.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.farmmanagement.DTO.request.CropRequestDTO;
import com.example.farmmanagement.DTO.request.CropUpdateRequestDTO;
import com.example.farmmanagement.DTO.response.CropResponseDTO;
import com.example.farmmanagement.entity.Crop;
import com.example.farmmanagement.exception.ResourceNotFoundException;
import com.example.farmmanagement.mapper.CropMapper;
import com.example.farmmanagement.repository.CropRepository;

@Service
@Transactional
public class CropServiceImpl implements CropService {

    private final CropRepository cropRepository;
    private final CropMapper cropMapper;

    public CropServiceImpl(
            CropRepository cropRepository,
            CropMapper cropMapper) {
        this.cropRepository = cropRepository;
        this.cropMapper = cropMapper;
    }

    // Create Crop
    @Override
    public CropResponseDTO createCrop(CropRequestDTO requestDTO) {

        Crop crop = cropMapper.toEntity(requestDTO);
        Crop savedCrop = cropRepository.save(crop);

        return cropMapper.toResponseDTO(savedCrop);
    }

    // Get Crop By ID
    @Override
    @Transactional(readOnly = true)
    public CropResponseDTO getCropById(Long cropId) {

        Crop crop = cropRepository.findById(cropId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Crop not found with ID: " + cropId));

        return cropMapper.toResponseDTO(crop);
    }

    // Get All Crops
    @Override
    @Transactional(readOnly = true)
    public List<CropResponseDTO> getAllCrops() {

        return cropRepository.findAll()
                .stream()
                .map(cropMapper::toResponseDTO)
                .toList();
    }

    // Update Crop
    @Override
    public CropResponseDTO updateCrop(
            Long cropId,
            CropUpdateRequestDTO requestDTO) {

        Crop crop = cropRepository.findById(cropId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Crop not found with ID: " + cropId));

        crop.setCropName(requestDTO.getCropName());
        crop.setCropCategory(requestDTO.getCropCategory());
        crop.setExpectedDurationDays(
                requestDTO.getExpectedDurationDays());
        crop.setDescription(requestDTO.getDescription());

        Crop updatedCrop = cropRepository.save(crop);

        return cropMapper.toResponseDTO(updatedCrop);
    }

    // Delete Crop
    @Override
    public void deleteCrop(Long cropId) {

        Crop crop = cropRepository.findById(cropId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Crop not found with ID: " + cropId));

        cropRepository.delete(crop);
    }
}
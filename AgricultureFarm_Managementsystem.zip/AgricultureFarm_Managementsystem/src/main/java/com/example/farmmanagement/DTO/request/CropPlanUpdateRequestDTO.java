package com.example.farmmanagement.DTO.request;

	import java.time.LocalDate;

	import com.example.farmmanagement.enums.Season;

	import jakarta.validation.constraints.NotNull;
	import jakarta.validation.constraints.Positive;
    import com.example.farmmanagement.enums.CropStatus;
	public class CropPlanUpdateRequestDTO {

	    @NotNull(message = "Season is required")
	    private Season season;

	    @NotNull(message = "Plan year is required")
	    @Positive(message = "Plan year must be positive")
	    private Integer planYear;

	    @NotNull(message = "Planned sowing date is required")
	    private LocalDate plannedSowingDate;

	    @NotNull(message = "Planned harvest date is required")
	    private LocalDate plannedHarvestDate;
	    @NotNull(message = "Crop Status is required")
	    private CropStatus status;

	    public CropPlanUpdateRequestDTO() {
	    }

	    public Season getSeason() {
	        return season;
	    }

	    public void setSeason(Season season) {
	        this.season = season;
	    }

	    public Integer getPlanYear() {
	        return planYear;
	    }

	    public void setPlanYear(Integer planYear) {
	        this.planYear = planYear;
	    }

	    public LocalDate getPlannedSowingDate() {
	        return plannedSowingDate;
	    }

	    public void setPlannedSowingDate(LocalDate plannedSowingDate) {
	        this.plannedSowingDate = plannedSowingDate;
	    }

	    public LocalDate getPlannedHarvestDate() {
	        return plannedHarvestDate;
	    }

	    public void setPlannedHarvestDate(LocalDate plannedHarvestDate) {
	        this.plannedHarvestDate = plannedHarvestDate;
	        
	    }
	    public CropStatus getStatus() {
	        return status;
	    }

	    public void setStatus(CropStatus status) {
	        this.status = status;
	    }
	}
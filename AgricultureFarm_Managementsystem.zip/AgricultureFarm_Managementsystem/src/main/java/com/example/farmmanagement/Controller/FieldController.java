package com.example.farmmanagement.Controller;

	import java.util.List;

	import org.springframework.http.HttpStatus;
	import org.springframework.http.ResponseEntity;
	import org.springframework.web.bind.annotation.DeleteMapping;
	import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.PathVariable;
	import org.springframework.web.bind.annotation.PostMapping;
	import org.springframework.web.bind.annotation.PutMapping;
	import org.springframework.web.bind.annotation.RequestBody;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.bind.annotation.RestController;

	import com.example.farmmanagement.DTO.request.FieldRequestDTO;
	import com.example.farmmanagement.DTO.request.FieldUpdateRequestDTO;
	import com.example.farmmanagement.DTO.response.FieldResponseDTO;
	import com.example.farmmanagement.service.FieldService;

	import jakarta.validation.Valid;

	@RestController
	@RequestMapping("/api/fields")
	public class FieldController {

	    private final FieldService fieldService;

	    public FieldController(FieldService fieldService) {
	        this.fieldService = fieldService;
	    }

	    // Create a new field
	    @PostMapping
	    public ResponseEntity<FieldResponseDTO> createField(
	            @Valid @RequestBody FieldRequestDTO requestDTO) {

	        FieldResponseDTO response =
	                fieldService.createField(requestDTO);

	        return ResponseEntity.status(HttpStatus.CREATED).body(response);
	    }

	    // Get a field by ID
	    @GetMapping("/{fieldId}")
	    public ResponseEntity<FieldResponseDTO> getFieldById(
	            @PathVariable Long fieldId) {

	        FieldResponseDTO response =
	                fieldService.getFieldById(fieldId);

	        return ResponseEntity.ok(response);
	    }

	    // Get all fields
	    @GetMapping
	    public ResponseEntity<List<FieldResponseDTO>> getAllFields() {

	        List<FieldResponseDTO> response =
	                fieldService.getAllFields();

	        return ResponseEntity.ok(response);
	    }

	    // Update a field
	    @PutMapping("/{fieldId}")
	    public ResponseEntity<FieldResponseDTO> updateField(
	            @PathVariable Long fieldId,
	            @Valid @RequestBody FieldUpdateRequestDTO requestDTO) {

	        FieldResponseDTO response =
	                fieldService.updateField(fieldId, requestDTO);

	        return ResponseEntity.ok(response);
	    }

	    // Delete a field
	    @DeleteMapping("/{fieldId}")
	    public ResponseEntity<Void> deleteField(
	            @PathVariable Long fieldId) {

	        fieldService.deleteField(fieldId);

	        return ResponseEntity.noContent().build();
	    }
	}
package com.example.farmmanagement.service;

	import static org.junit.jupiter.api.Assertions.assertNotNull;
	import static org.junit.jupiter.api.Assertions.assertEquals;
	import static org.mockito.Mockito.verify;
	import static org.mockito.Mockito.when;

	import java.util.Optional;

	import org.junit.jupiter.api.BeforeEach;
	import org.junit.jupiter.api.Test;
	import org.junit.jupiter.api.extension.ExtendWith;
	import org.mockito.InjectMocks;
	import org.mockito.Mock;
	import org.mockito.junit.jupiter.MockitoExtension;

	import com.example.farmmanagement.DTO.response.FarmResponseDTO;
	import com.example.farmmanagement.entity.Farm;
	import com.example.farmmanagement.exception.ResourceNotFoundException;
	import com.example.farmmanagement.mapper.FarmMapper;
	import com.example.farmmanagement.repository.FarmRepository;

	import static org.junit.jupiter.api.Assertions.assertThrows;

	@ExtendWith(MockitoExtension.class)
	class FarmServiceImplTest {

	    @Mock
	    private FarmRepository farmRepository;

	    @Mock
	    private FarmMapper farmMapper;

	    @InjectMocks
	    private FarmServiceImpl farmService;

	    private Farm farm;
	    private FarmResponseDTO responseDTO;

	    @BeforeEach
	    void setUp() {
	        farm = new Farm();
	        farm.setFarmId(5L);
	        farm.setFarmName("Green Valley Farm");
	        farm.setLocation("Hyderabad, Telangana");
	        farm.setTotalArea(10.5);
	        farm.setDescription("Test farm");

	        responseDTO = new FarmResponseDTO();
	    }

	    @Test
	    void getFarmById_shouldReturnFarm_whenFarmExists() {

	        when(farmRepository.findById(5L))
	                .thenReturn(Optional.of(farm));

	        when(farmMapper.toResponseDTO(farm))
	                .thenReturn(responseDTO);

	        FarmResponseDTO result = farmService.getFarmById(5L);

	        assertNotNull(result);
	        verify(farmRepository).findById(5L);
	        verify(farmMapper).toResponseDTO(farm);
	    }

	    @Test
	    void getFarmById_shouldThrowException_whenFarmDoesNotExist() {

	        when(farmRepository.findById(999L))
	                .thenReturn(Optional.empty());

	        assertThrows(
	                ResourceNotFoundException.class,
	                () -> farmService.getFarmById(999L));

	        verify(farmRepository).findById(999L);
	    }
	}
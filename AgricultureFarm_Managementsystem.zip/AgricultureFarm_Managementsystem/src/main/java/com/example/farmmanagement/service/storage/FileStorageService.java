package com.example.farmmanagement.service.storage;

	import java.io.IOException;
	import java.nio.file.Files;
	import java.nio.file.Path;
	import java.nio.file.Paths;
	import java.util.UUID;

	import org.springframework.beans.factory.annotation.Value;
	import org.springframework.stereotype.Service;
	import org.springframework.web.multipart.MultipartFile;
	import org.springframework.util.StringUtils;

	@Service
	public class FileStorageService {

	    private final Path uploadPath;

	    public FileStorageService(
	            @Value("${app.file.upload-dir}") String uploadDirectory) {

	        this.uploadPath = Paths.get(uploadDirectory)
	                .toAbsolutePath()
	                .normalize();

	        try {
	            Files.createDirectories(uploadPath);
	        } catch (IOException e) {
	            throw new IllegalStateException(
	                    "Could not create upload directory.", e);
	        }
	    }

	    public String storeFile(MultipartFile file) {

	        if (file == null || file.isEmpty()) {
	            throw new IllegalArgumentException(
	                    "Please select a file to upload.");
	        }

	        String originalFileName =
	                StringUtils.cleanPath(file.getOriginalFilename() == null
	                        ? "" : file.getOriginalFilename());

	        if (originalFileName.isBlank()
	                || originalFileName.contains("..")
	                || originalFileName.contains("/")
	                || originalFileName.contains("\\")) {
	            throw new IllegalArgumentException("Invalid file name.");
	        }

	        String extension = "";
	        int dotIndex = originalFileName.lastIndexOf('.');

	        if (dotIndex > 0) {
	            extension = originalFileName.substring(dotIndex);
	        }

	        String storedFileName = UUID.randomUUID() + extension;
	        Path targetPath = uploadPath.resolve(storedFileName).normalize();

	        if (!targetPath.startsWith(uploadPath)) {
	            throw new IllegalArgumentException("Invalid file path.");
	        }

	        try {
	            Files.copy(file.getInputStream(), targetPath);
	            return storedFileName;
	        } catch (IOException e) {
	            throw new IllegalStateException(
	                    "Could not store the uploaded file.", e);
	        }
	    }

	    public Path loadFile(String storedFileName) {

	        if (storedFileName == null
	                || !storedFileName.matches(
	                        "[a-zA-Z0-9-]+(\\.[a-zA-Z0-9]+)?")) {
	            throw new IllegalArgumentException(
	                    "Invalid stored file name.");
	        }

	        Path filePath = uploadPath.resolve(storedFileName).normalize();

	        if (!filePath.startsWith(uploadPath)) {
	            throw new IllegalArgumentException("Invalid file path.");
	        }

	        return filePath;
	    }

	    public void deleteFile(String storedFileName) {

	        try {
	            Files.deleteIfExists(loadFile(storedFileName));
	        } catch (IOException e) {
	            throw new IllegalStateException(
	                    "Could not delete the stored file.", e);
	        }
	    }
	}
package com.example.farmmanagement.enums;

public enum DocumentType {

	    SEED,
	    FERTILIZER,
	    PESTICIDE,
	    HERBICIDE,
	    WATER,
	    FUEL,
	    ELECTRICITY,
	    FARM_EQUIPMENT,
	    LABOUR
	}
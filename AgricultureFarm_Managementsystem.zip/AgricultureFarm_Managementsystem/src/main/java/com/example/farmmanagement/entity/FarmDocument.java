package com.example.farmmanagement.entity;

	import com.example.farmmanagement.enums.DocumentType;
	import jakarta.persistence.*;
	import jakarta.validation.constraints.NotBlank;
	import jakarta.validation.constraints.NotNull;

	import java.time.LocalDateTime;

	@Entity
	@Table(name = "farm_documents")
	public class FarmDocument {

	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long documentId;

	    @ManyToOne(fetch = FetchType.LAZY, optional = false)
	    @JoinColumn(
	        name = "farm_id",
	        nullable = false,
	        foreignKey = @ForeignKey(name = "fk_document_farm")
	    )
	    private Farm farm;

	    @NotBlank(message = "Original file name is required")
	    @Column(name = "original_file_name", nullable = false, length = 255)
	    private String originalFileName;

	    @NotBlank(message = "Stored file name is required")
	    @Column(name = "stored_file_name", nullable = false, unique = true, length = 255)
	    private String storedFileName;

	    @NotBlank(message = "File type is required")
	    @Column(name = "file_type", nullable = false, length = 100)
	    private String fileType;

	    @NotNull(message = "Document type is required")
	    @Enumerated(EnumType.STRING)
	    @Column(name = "document_type", nullable = false, length = 50)
	    private DocumentType documentType;

	    @Column(name = "file_size", nullable = false)
	    private Long fileSize;

	    @Column(name = "uploaded_at", nullable = false)
	    private LocalDateTime uploadedAt;

	    @Column(length = 500)
	    private String description;

	    public FarmDocument() {
	    }

	    public Long getDocumentId() {
	        return documentId;
	    }

	    public void setDocumentId(Long documentId) {
	        this.documentId = documentId;
	    }

	    public Farm getFarm() {
	        return farm;
	    }

	    public void setFarm(Farm farm) {
	        this.farm = farm;
	    }

	    public String getOriginalFileName() {
	        return originalFileName;
	    }

	    public void setOriginalFileName(String originalFileName) {
	        this.originalFileName = originalFileName;
	    }

	    public String getStoredFileName() {
	        return storedFileName;
	    }

	    public void setStoredFileName(String storedFileName) {
	        this.storedFileName = storedFileName;
	    }

	    public String getFileType() {
	        return fileType;
	    }

	    public void setFileType(String fileType) {
	        this.fileType = fileType;
	    }

	    public DocumentType getDocumentType() {
	        return documentType;
	    }

	    public void setDocumentType(DocumentType documentType) {
	        this.documentType = documentType;
	    }

	    public Long getFileSize() {
	        return fileSize;
	    }

	    public void setFileSize(Long fileSize) {
	        this.fileSize = fileSize;
	    }

	    public LocalDateTime getUploadedAt() {
	        return uploadedAt;
	    }

	    public void setUploadedAt(LocalDateTime uploadedAt) {
	        this.uploadedAt = uploadedAt;
	    }

	    public String getDescription() {
	        return description;
	    }

	    public void setDescription(String description) {
	        this.description = description;
	    }
	}
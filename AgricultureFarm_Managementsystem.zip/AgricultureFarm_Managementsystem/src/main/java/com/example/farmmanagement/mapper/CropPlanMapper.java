package com.example.farmmanagement.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.example.farmmanagement.DTO.request.CropPlanRequestDTO;
import com.example.farmmanagement.DTO.response.CropPlanResponseDTO;
import com.example.farmmanagement.entity.CropPlan;

@Mapper(componentModel = "spring")
public interface CropPlanMapper {

    @Mapping(target = "cropPlanId", ignore = true)
    @Mapping(target = "field.fieldId", source = "fieldId")
    @Mapping(target = "crop.cropId", source = "cropId")
    @Mapping(target = "activities", ignore = true)
    CropPlan toEntity(CropPlanRequestDTO requestDTO);

    @Mapping(target = "fieldId", source = "field.fieldId")
    @Mapping(target = "cropId", source = "crop.cropId")
    CropPlanResponseDTO toResponseDTO(CropPlan cropPlan);
}
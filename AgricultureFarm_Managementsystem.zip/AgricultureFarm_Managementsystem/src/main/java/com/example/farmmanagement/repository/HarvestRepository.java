package com.example.farmmanagement.repository;

	import org.springframework.data.jpa.repository.JpaRepository;
	import org.springframework.stereotype.Repository;

	import com.example.farmmanagement.entity.Harvest;

	@Repository
	public interface HarvestRepository extends JpaRepository<Harvest, Long> {

	}
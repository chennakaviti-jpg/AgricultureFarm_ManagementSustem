package com.example.farmmanagement.service;

	import java.util.List;

	import com.example.farmmanagement.DTO.request.CropMonitoringRequestDTO;
	import com.example.farmmanagement.DTO.request.CropMonitoringUpdateRequestDTO;
	import com.example.farmmanagement.DTO.response.CropMonitoringResponseDTO;

	public interface CropMonitoringService {

	    CropMonitoringResponseDTO recordMonitoring(
	            CropMonitoringRequestDTO requestDTO);

	    CropMonitoringResponseDTO getMonitoringById(Long monitoringId);

	    List<CropMonitoringResponseDTO> getAllMonitoringRecords();

	    CropMonitoringResponseDTO updateMonitoring(
	            Long monitoringId,
	            CropMonitoringUpdateRequestDTO requestDTO);

	    void deleteMonitoring(Long monitoringId);
	}
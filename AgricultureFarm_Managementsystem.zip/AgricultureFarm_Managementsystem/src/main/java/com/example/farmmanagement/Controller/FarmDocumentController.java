package com.example.farmmanagement.Controller;

import java.util.List;

import org.springframework.core.io.Resource;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.example.farmmanagement.DTO.request.FarmDocumentRequestDTO;
import com.example.farmmanagement.DTO.request.FarmDocumentUpdateRequestDTO;
import com.example.farmmanagement.DTO.response.FarmDocumentResponseDTO;
import com.example.farmmanagement.enums.DocumentType;
import com.example.farmmanagement.service.FarmDocumentService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/farm-documents")
public class FarmDocumentController {

    private final FarmDocumentService farmDocumentService;

    public FarmDocumentController(FarmDocumentService farmDocumentService) {
        this.farmDocumentService = farmDocumentService;
    }

    @PostMapping
    public ResponseEntity<FarmDocumentResponseDTO> createFarmDocument(
            @Valid @RequestBody FarmDocumentRequestDTO requestDTO) {

        return ResponseEntity.status(201)
                .body(farmDocumentService.createDocument(requestDTO));
    }

    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<FarmDocumentResponseDTO> uploadDocument(
            @RequestParam Long farmId,
            @RequestParam DocumentType documentType,
            @RequestParam(required = false) String description,
            @RequestParam("file") MultipartFile file) {

        FarmDocumentResponseDTO response =
                farmDocumentService.uploadDocument(
                        farmId, documentType, description, file);

        return ResponseEntity.status(201).body(response);
    }

    @GetMapping("/{documentId}/download")
    public ResponseEntity<Resource> downloadDocument(
            @PathVariable Long documentId) {

        Resource resource =
                farmDocumentService.downloadDocument(documentId);

        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        ContentDisposition.attachment()
                                .filename(resource.getFilename())
                                .build().toString())
                .body(resource);
    }

    @GetMapping("/{documentId}")
    public ResponseEntity<FarmDocumentResponseDTO> getFarmDocumentById(
            @PathVariable Long documentId) {

        return ResponseEntity.ok(
                farmDocumentService.getDocumentById(documentId));
    }

    @GetMapping
    public ResponseEntity<List<FarmDocumentResponseDTO>> getAllFarmDocuments() {

        return ResponseEntity.ok(
                farmDocumentService.getAllDocuments());
    }

    @PutMapping("/{documentId}")
    public ResponseEntity<FarmDocumentResponseDTO> updateFarmDocument(
            @PathVariable Long documentId,
            @Valid @RequestBody FarmDocumentUpdateRequestDTO requestDTO) {

        return ResponseEntity.ok(
                farmDocumentService.updateDocument(documentId, requestDTO));
    }

    @DeleteMapping("/{documentId}")
    public ResponseEntity<Void> deleteFarmDocument(
            @PathVariable Long documentId) {

        farmDocumentService.deleteDocument(documentId);

        return ResponseEntity.noContent().build();
    }
}
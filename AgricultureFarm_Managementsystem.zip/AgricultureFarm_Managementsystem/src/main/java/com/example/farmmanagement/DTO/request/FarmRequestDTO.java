package com.example.farmmanagement.DTO.request;

	import jakarta.validation.constraints.DecimalMin;
	import jakarta.validation.constraints.NotBlank;
	import jakarta.validation.constraints.NotNull;
	import jakarta.validation.constraints.Positive;

	import jakarta.validation.constraints.Size;

	public class FarmRequestDTO {

	    @NotBlank(message = "Farm name is required")
	    @Size(max = 100, message = "Farm name cannot exceed 100 characters")
	    private String farmName;

	    @NotBlank(message = "Farm location is required")
	    @Size(max = 255, message = "Location cannot exceed 255 characters")
	    private String location;

	    @NotNull(message = "Total farm area is required")
	    @DecimalMin(value = "0.0", inclusive = false,
	            message = "Farm area must be greater than zero")
	    private Double totalArea;

	    private String description;

	    @NotNull(message = "Farmer ID is required")
	    @Positive(message = "Farmer ID must be a positive number")
	    private Long farmerId;

	    public FarmRequestDTO() {
	    }

	    public String getFarmName() {
	        return farmName;
	    }

	    public void setFarmName(String farmName) {
	        this.farmName = farmName;
	    }

	    public String getLocation() {
	        return location;
	    }

	    public void setLocation(String location) {
	        this.location = location;
	    }

	    public Double getTotalArea() {
	        return totalArea;
	    }

	    public void setTotalArea(Double totalArea) {
	        this.totalArea = totalArea;
	    }

	    public String getDescription() {
	        return description;
	    }

	    public void setDescription(String description) {
	        this.description = description;
	    }

	    public Long getFarmerId() {
	        return farmerId;
	    }

	    public void setFarmerId(Long farmerId) {
	        this.farmerId = farmerId;
	    }
	}
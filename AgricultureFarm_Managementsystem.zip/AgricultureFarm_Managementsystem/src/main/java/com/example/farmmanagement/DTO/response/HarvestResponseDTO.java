package com.example.farmmanagement.DTO.response;

	import java.time.LocalDate;

	import com.example.farmmanagement.enums.HarvestStatus;
	import com.example.farmmanagement.enums.MeasurementUnit;

	public class HarvestResponseDTO {

	    private Long harvestId;
	    private Long cropPlanId;
	    private LocalDate harvestDate;
	    private Double quantity;
	    private MeasurementUnit unit;
	    private Double expectedPrice;
	    private Double actualRevenue;
	    private HarvestStatus status;
	    private String remarks;

	    public HarvestResponseDTO() {
	    }

	    public Long getHarvestId() {
	        return harvestId;
	    }

	    public void setHarvestId(Long harvestId) {
	        this.harvestId = harvestId;
	    }

	    public Long getCropPlanId() {
	        return cropPlanId;
	    }

	    public void setCropPlanId(Long cropPlanId) {
	        this.cropPlanId = cropPlanId;
	    }

	    public LocalDate getHarvestDate() {
	        return harvestDate;
	    }

	    public void setHarvestDate(LocalDate harvestDate) {
	        this.harvestDate = harvestDate;
	    }

	    public Double getQuantity() {
	        return quantity;
	    }

	    public void setQuantity(Double quantity) {
	        this.quantity = quantity;
	    }

	    public MeasurementUnit getUnit() {
	        return unit;
	    }

	    public void setUnit(MeasurementUnit unit) {
	        this.unit = unit;
	    }

	    public Double getExpectedPrice() {
	        return expectedPrice;
	    }

	    public void setExpectedPrice(Double expectedPrice) {
	        this.expectedPrice = expectedPrice;
	    }

	    public Double getActualRevenue() {
	        return actualRevenue;
	    }

	    public void setActualRevenue(Double actualRevenue) {
	        this.actualRevenue = actualRevenue;
	    }

	    public HarvestStatus getStatus() {
	        return status;
	    }

	    public void setStatus(HarvestStatus status) {
	        this.status = status;
	    }

	    public String getRemarks() {
	        return remarks;
	    }

	    public void setRemarks(String remarks) {
	        this.remarks = remarks;
	    }
	}